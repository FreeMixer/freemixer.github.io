/** The contract directories, in the order they are read: `$OMX_CONTRACT_PATH`, else omx-contract's `contractdir`,
 * else the default. */
export function contractDirs(): string[];
/** The directory `<contractdir>/3/<package>` of the first contract directory that holds it, or undefined. */
export function packageDir(pkg: any): string | undefined;
/** omx-contract's own data directory: its pkg-config `datadir`, else the default. */
export function contractDataDir(): string;
/** The installed omx-contract schema, where the descriptor words are declared. */
export function contractSchemaFile(): string;
/** The meaning role `role` plays, or undefined when the descriptor has no word for it. */
export function meaningOfRole(role: any): any;
/** The file of plugin-hostd's LV2 table: in `$PLUGIN_HOSTD_TABLES`, else in the first contract directory holding
 * plugin-hostd (named in the first one when none does). */
export function lv2TableFile(): string;
/** The param-contract header: `$OMX_PARAM_CONTRACT_H`, else under omxplugins' pkg-config `includedir`, else the
 * default; undefined when none is there. */
export function paramContractHeader(): string | undefined;
/** A descriptor unit's token: the LV2 unit a face writes for it (units:db -> db, urn:openmixer:unit#dBFS -> dbfs), else
 * the name of a vendor-block unit it is (dBu -> dbu), else undefined. */
export function unitTokenOf(unit: any): any;
/** The token of a unit the param-contract extension serves (one with a header value, or "" for none), else undefined. */
export function servedToken(unit: any): any;
/** Every unit plugin-hostd's LV2 table maps, and "", with its contract unit: `{ <unit>: [token, header value] }`, a unit
 * the header has no value for `['none', 0]`. */
export function contractUnits(): {
    [k: string]: any[];
};
/** The descriptor file a package installed into omx-contract's contract directory, `<package>/<name>`:
 * `<contractdir>/3/<package>/plugins/<name>.json`. */
export function installedDescriptorFile(ref: any): string;
/** Every descriptor file installed under the contract directories, sorted: `<contractdir>/<major>/<package>/plugins/*.json`,
 * whatever majors are installed. A `<package>/<name>` installed under several majors or directories is listed once,
 * from the highest major of the first contract directory that holds it. */
export function installedDescriptorFiles(): any[];
/** Where omx-contract-data installs its files and the contract directory, for an install with no omx-contract.pc. */
export const DEFAULT_DATADIR: "/usr/share/omx-contract";
export const DEFAULT_CONTRACTDIR: "/usr/share/omx-contract/contract.d";
export function meanings(): any;
/** A panel role -> the descriptor meaning it plays, where the two names differ. A role whose name is
 * a meaning plays that meaning; a role in neither has no meaning word and is bound only by a panel. */
export const MEANING_OF_ROLE: Readonly<{
    mix: "wetDryRatio";
    time: "delay";
    cutoff: "cutoffFrequency";
    band_freq: "frequency";
    band_gain: "gain";
    band_q: "q";
    hpf_freq: "lowCut";
    low_cut: "lowCut";
    lpf_freq: "highCut";
    high_cut: "highCut";
    hpf_slope: "slope";
    lpf_slope: "slope";
    key_listen: "listen";
}>;
export function lv2UnitTable(): any;
export function headerUnits(): any;
