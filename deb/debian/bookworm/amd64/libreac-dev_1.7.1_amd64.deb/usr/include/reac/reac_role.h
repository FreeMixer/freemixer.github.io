// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 Pau Aliagas <linuxnow@gmail.com>

/* reac_role — the MASTER/SLAVE role selection, factored out of main.c so the
 * parse + validation contract is unit-testable without PipeWire/sockets.
 *
 * REAC has no fixed master: any box can be the master and the rest slave to it
 * (REAC-PROTOCOL-AND-TESTS.md §2/§4). openmixer must fit either role:
 *   - master (default): WE drive the cdea/cfea establishment and WE GENERATE THE
 *     PACE (the SCHED_FIFO pacer's cadence); a stagebox slaves to us.
 *   - slave: an EXTERNAL master drives; we RESPOND and lock to its cadence (frame
 *     arrival is our slot clock) + return our input channels upstream.
 * Both share the encoder/decoder + the PipeWire nodes; only WHO drives the
 * handshake and WHO GENERATES THE PACE differs.
 *
 * The role says nothing about the CLOCK REFERENCE. Generating the pace does not
 * make us the clock master — the cadence we generate should itself be disciplined
 * to a reference (a word clock, a PHC, locked graph hardware), and there is exactly
 * one clock master on a network. See reac_clock.h; keeping role / pace / clock
 * reference distinct is deliberate. */
#ifndef REAC_ROLE_H
#define REAC_ROLE_H

#include <string.h>

enum reac_role {
	REAC_ROLE_MASTER = 0,   /* default — preserves the original behaviour */
	REAC_ROLE_SLAVE,
};

/* Parse a --role argument string. Returns 0 + sets *out on success, -1 on an
 * unknown value (caller reports the error). NULL/"" is treated as unknown. */
static inline int reac_role_parse(const char *s, enum reac_role *out)
{
	if (!s)
		return -1;
	if (!strcmp(s, "master")) { *out = REAC_ROLE_MASTER; return 0; }
	if (!strcmp(s, "slave"))  { *out = REAC_ROLE_SLAVE;  return 0; }
	return -1;
}

/* The role's human name (for logs/usage). */
static inline const char *reac_role_name(enum reac_role r)
{
	return r == REAC_ROLE_SLAVE ? "slave" : "master";
}

/* WHAT WE ASKED TO BE, which is not the same fact as what we present on the wire
 * Intent and observation are two facts, and two facts need two fields.
 * `enum reac_role` above is the WIRE vocabulary and has exactly two values, because a
 * frame goes out as one end of the pairing or the other. The INTENT has a third:
 *
 *   auto — observe first, then take the role the segment leaves open, and it is the
 *          product default: no master on the wire, we master it; a DESK masters it, we
 *          slave to it; a STAGEBOX masters it, we refuse and say so. reac_hunt.h
 *          resolves it from what the wire actually says.
 *
 * A console face may speak its own words for the same two ends (openmixer's shows
 * `mixer`/`recorder`); REAC_ROLE and this parser stay on the WIRE's words, and the
 * translation is the console's to do. */
enum reac_role_intent {
	REAC_ROLE_INTENT_AUTO = 0,   /* the default: the wire decides (reac_hunt.h) */
	REAC_ROLE_INTENT_MASTER,
	REAC_ROLE_INTENT_SLAVE,
	/* tap — SERVE WHAT IS HEARD AND TRANSMIT NOTHING. Not an end of the pairing at
	 * all: no announce, no join, no grant, no seglock, no TX socket. It is the only
	 * intent that has no wire role even after the wire has answered, which is why it
	 * cannot be spelled as a value of `enum reac_role` above. See
	 * <reac/transport/reac_tap.h>, and openmixer's master-arbitration spec, eighth
	 * amendment (2026-09-13): beside a real desk, a courting slave of ours kept that
	 * desk's own box from enrolling for 180 s and a granted one blocked it outright.
	 * EXPLICIT ONLY — `auto` never resolves to it. */
	REAC_ROLE_INTENT_TAP,
	/* box — WE ARE THE STAGEBOX. The mixer masters the wire and we present a box
	 * to it: we answer with a MODEL ROW's declaration and identity, follow its
	 * scene push and chanmap, pace as a slave, and return its channels. On the
	 * wire this is the slave end of the pairing — reac_slave is the engine and
	 * there is no second one — so what `box` adds is an INTENT: which model we
	 * declare, and which way round the two PipeWire doors face
	 * (reac-pw 2026-09-17-the-daemon-can-be-a-box).
	 *
	 * EXPLICIT ONLY, exactly like `tap` and for the mirror-image reason: a mixer
	 * never wants a surprise stagebox appearing on its fabric and taking
	 * channels. `auto` resolves to master, slave, tap or refused, and never to
	 * this. */
	REAC_ROLE_INTENT_BOX,
};

/* Can an election ARRIVE at this intent, or must an operator have asked for it?
 * Two intents are explicit-only and they are the two that change what the desk
 * on the other end SEES: a tap that never speaks, and a box that claims
 * channels. Asked here rather than by comparing against two constants at every
 * election site, because a third one would be missed at one of them. */
static inline int reac_role_intent_explicit_only(enum reac_role_intent i)
{
	return i == REAC_ROLE_INTENT_TAP || i == REAC_ROLE_INTENT_BOX;
}

/* Does this intent put ANYTHING on the wire? A caller that opens a socket, claims a
 * segment lock or starts an engine asks this first; `tap` is the one answer that is 0,
 * and it is 0 whatever the wire turns out to be carrying. */
static inline int reac_role_intent_transmits(enum reac_role_intent i)
{
	return i != REAC_ROLE_INTENT_TAP;
}

/* Parse a REAC_ROLE value. Returns 0 + sets *out on success, -1 on an unknown value
 * (caller reports it). NULL/"" is unknown, never `auto`: an absent key is resolved by
 * the caller's own default, and a key set to a word nobody can read is a mistake worth
 * naming. */
static inline int reac_role_intent_parse(const char *s, enum reac_role_intent *out)
{
	if (!s)
		return -1;
	if (!strcmp(s, "auto"))   { *out = REAC_ROLE_INTENT_AUTO;   return 0; }
	if (!strcmp(s, "master")) { *out = REAC_ROLE_INTENT_MASTER; return 0; }
	if (!strcmp(s, "slave"))  { *out = REAC_ROLE_INTENT_SLAVE;  return 0; }
	if (!strcmp(s, "tap"))    { *out = REAC_ROLE_INTENT_TAP;    return 0; }
	if (!strcmp(s, "box"))    { *out = REAC_ROLE_INTENT_BOX;    return 0; }
	return -1;
}

static inline const char *reac_role_intent_name(enum reac_role_intent i)
{
	switch (i) {
	case REAC_ROLE_INTENT_MASTER: return "master";
	case REAC_ROLE_INTENT_SLAVE:  return "slave";
	case REAC_ROLE_INTENT_TAP:    return "tap";
	case REAC_ROLE_INTENT_BOX:    return "box";
	case REAC_ROLE_INTENT_AUTO:
	default:                      return "auto";
	}
}

/* The wire role an intent LAUNCHES in before the wire has answered. `auto` launches as
 * master only because a role field must hold one of two values; nothing is transmitted
 * on it — the hunt gates the actual open (reac_hunt.h).
 *
 * `tap` HAS NO ANSWER HERE and the caller must not need one: it is gated by
 * reac_role_intent_transmits before any engine is chosen, and it reads master here for
 * the same reason `auto` does — the field holds one of two values — while nothing is
 * ever transmitted on it. */
static inline enum reac_role reac_role_from_intent(enum reac_role_intent i)
{
	/* A BOX IS THE SLAVE END OF THE PAIRING. The mixer drives, we answer — the
	 * same wire role, a different declaration (see the intent's own comment). */
	return (i == REAC_ROLE_INTENT_SLAVE || i == REAC_ROLE_INTENT_BOX)
	               ? REAC_ROLE_SLAVE : REAC_ROLE_MASTER;
}

/* Validate a parsed role against the other CLI options. The slave role REQUIRES a
 * TX NIC (the upstream return + handshake socket); the master role can run RX-only
 * (a pure monitor) or with --tx for the downstream sink. Returns 0 if OK, -1 if
 * the combination is invalid (caller reports which). `have_tx` = was --tx given. */
static inline int reac_role_validate(enum reac_role r, int have_tx)
{
	if (r == REAC_ROLE_SLAVE && !have_tx)
		return -1;   /* slave needs a NIC to return its inputs + handshake on */
	return 0;
}

#endif /* REAC_ROLE_H */
