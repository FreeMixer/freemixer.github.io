/* SPDX-License-Identifier: GPL-3.0-or-later
 * Copyright (C) 2026 Pau Aliagas <linuxnow@gmail.com>
 *
 * omx_gate_instance.h — the strip gate as a plugin instance: the shell's core, with no format in it.
 *
 * The shape is omx-plugins' omx_delay_instance.h's (one C core, N shells). The core here is `omx_gate.h` — its
 * `omx_gate_resolve` (the console's gateStateToNativeDyn as control reads) and its `omx_gate_run`
 * (the host's block through fixed scratch by `omx_dynamics_keyed`, THE SAME kernel the console's
 * gate slot runs) — and this file adds no DSP to it. What it adds is what a host's port model
 * needs and `omx_gate.h`'s pointer-per-port face does not carry:
 *
 *   1. READY. {@link omx_gate_instance_init} binds the instance to its rate and refuses a rate
 *      that is not positive. A refused instance is the identity in {@link omx_gate_instance_run}
 *      and reports no latency: absence is a wire, not a crash.
 *   2. RESOLVE. A host publishes control ports as floats in the operator's units (dB, ratio, ms,
 *      toggles). {@link omx_gate_instance_resolve} takes them BY VALUE, in the gate kernel's
 *      contract order (omx-contract 2.7.0), and hands them to `omx_gate_resolve` — the one
 *      resolution, never a second one — so every value lands inside the declared OMX_GATE_*
 *      travel (NaN floored) whatever the host's port held, and `bypass` is the slot's `enabled`
 *      control inverted. The knee range, the hold and the hysteresis, which `omx_gate_resolve`
 *      leaves neutral, reach the kernel's own fields (`gc.knee_db` and `knee_shift_db` by
 *      omx_gate_knee, `omx_dyn.hold_frames` by omx_dyn_hold_frames at the instance rate,
 *      `hyst_db`), each clamped into its travel, a non-finite word at its default. A knee start
 *      equal to its end is the hard knee, the gate before the knee range, bit for bit. The key
 *      filter's edges (`hp_hz`, `lp_hz`, omx-contract 2.7.0) reach `omx_gate_resolve` through its
 *      controls, clamped into GATE_KEY_LIMITS, a non-finite edge out; both at 0 is the gate
 *      before the key filter, bit for bit.
 *   3. IN -> OUT. `omx_gate_run` already copies every block (inputs AND key) through its scratch,
 *      so any aliasing a host does (an output on its input, the key on an output) is safe.
 *
 * STATE ACROSS BYPASS: the kernel's disabled path leaves the slot's state as it was, and the
 * shell adds no re-arm the console's slot does not have. {@link omx_gate_instance_init} (a host's
 * instantiate/activate) is the one place the state is cleared.
 *
 * LATENCY IS PUBLISHED: OMX_OVS_LATENCY_4X while the attack engages the 4x control path (the
 * kernel's compensation delay), else 0 — `omx_gate_latency` over the resolved atom, never restated.
 *
 * Everything below is plain C; test/fx/gate_instance.test.c drives it with a plain `cc`.
 */
#ifndef OMX_GATE_INSTANCE_H
#define OMX_GATE_INSTANCE_H

#include <stdint.h>
#include <string.h>

#include <omxdsp/omx_gate.h>
#include <omxdsp/omx_param.h>

/** @brief Audio legs in and out: TWO, the strip gate's stereo pair (one detector, linked gain). */
#define OMX_GATE_INSTANCE_CHANNELS 2

/** @brief One instance: the rate, the resolved atom, the key-source control and the gate's state. */
typedef struct {
  float sr;
  struct omx_dyn atom;
  /** The key-source control as resolved: 1 listens to the key, 0 is SELF. */
  float key_external;
  struct omx_gate gate;
  int ready;
} OmxGateInstance;

/**
 * @brief Bind an instance to its rate (instantiate/activate): the slot's state cleared, base path,
 *        the atom resolved at the declared defaults (the knee range, hold and hysteresis
 *        included), the key filter out (its edges declare no come-up value), the key listened to
 *        as before (a run() handed no key is the self-detecting gate).
 * @param s The instance.
 * @param sr The host's sample rate, Hz.
 * @return 1 when usable, 0 when not (NULL instance, rate not positive or NaN); a refused instance
 *         is the identity.
 * @note No allocation; clears the whole instance. Thread-safe on distinct instances.
 */
static inline void omx_gate_instance_resolve(OmxGateInstance *s, int bypass, int key_source,
                                             float threshold_db, float range_db, float knee_start_db,
                                             float knee_end_db, float attack_ms, float hold_ms,
                                             float release_ms, float hysteresis_db, float ratio, float hp_hz,
                                             float lp_hz);

static inline int omx_gate_instance_init(OmxGateInstance *s, float sr) {
  if (!s) return 0;
  memset(s, 0, sizeof(*s));
  if (!(sr > 0.0f)) return 0;
  s->sr = sr;
  omx_gate_init(&s->gate, sr);
  s->ready = 1;
  omx_gate_instance_resolve(s, 0, 1, OMX_GATE_THRESHOLD_DB_DEFAULT, OMX_GATE_RANGE_DB_DEFAULT,
                            OMX_GATE_KNEE_START_DB_DEFAULT, OMX_GATE_KNEE_END_DB_DEFAULT,
                            OMX_GATE_ATTACK_MS_DEFAULT, OMX_GATE_HOLD_MS_DEFAULT, OMX_GATE_RELEASE_MS_DEFAULT,
                            OMX_GATE_HYSTERESIS_DB_DEFAULT, OMX_GATE_RATIO_DEFAULT, OMX_GATE_KEY_HP_HZ_MIN,
                            OMX_GATE_KEY_LP_HZ_MIN);
  return 1;
}

/* CONTRACT (omx_contract.h). The atom this leaves behind satisfies every PRE the kernel's gain
 * computer states — ratio at least the gate's floor, range an attenuation — and sits inside the
 * declared travel with poles in [0, 1), whatever the host's ports held. This is the shell's whole
 * promise to the kernel, and the POST below is that promise verbatim. */
#define OMX_CONTRACT_STAGE "gate/instance-resolve"
/**
 * @brief Resolve the host's control-port values into the gate's atom for one cycle.
 * @param s The instance; a refused one is left untouched.
 * @param bypass Non-zero disables the slot (the identity).
 * @param key_source The contract's keySource, as its index: 1 (sidechain) listens to the key handed to
 *        {@link omx_gate_instance_run}, 0 (self) to the gate's own input; any non-zero is sidechain.
 * @param threshold_db The open point, dB.
 * @param range_db The attenuation floor, dB.
 * @param knee_start_db One edge of the knee range, dB: where the curve leaves the expander's line.
 * @param knee_end_db The other edge, dB: where the curve reaches unity. Equal to `knee_start_db`
 *        is the hard knee; the range is rounded around the threshold as omx_gate_knee states.
 * @param attack_ms The attack, ms.
 * @param hold_ms The hold, ms: the gate stays open this long after the level falls below the close
 *        point; 0 is no hold.
 * @param release_ms The release, ms.
 * @param hysteresis_db The hysteresis, dB: the gate closes `hysteresis_db` below where it opens.
 * @param ratio The expansion ratio.
 * @param hp_hz The key filter's high-pass corner, Hz; 0 is out.
 * @param lp_hz The key filter's low-pass corner, Hz; 0 is out.
 * @post `atom-meets-the-kernel-preconditions`: every field inside the declared OMX_GATE_* travel,
 *       and the key filter's edges inside GATE_KEY_LIMITS.
 * @note RT-safe: two expf per call, and the key filter's design when an edge moves. Thread-safe on
 *       distinct instances.
 */
static inline void omx_gate_instance_resolve(OmxGateInstance *s, int bypass, int key_source,
                                             float threshold_db, float range_db, float knee_start_db,
                                             float knee_end_db, float attack_ms, float hold_ms,
                                             float release_ms, float hysteresis_db, float ratio, float hp_hz,
                                             float lp_hz) {
  if (!s || !s->ready) return;
  const float enabled = bypass ? 0.0f : 1.0f;
  s->key_external = key_source ? 1.0f : 0.0f;
  const float hp = omx_clamp_or(hp_hz, OMX_GATE_KEY_HP_HZ_MIN, OMX_GATE_KEY_HP_HZ_MAX, OMX_GATE_KEY_HP_HZ_MIN);
  const float lp = omx_clamp_or(lp_hz, OMX_GATE_KEY_LP_HZ_MIN, OMX_GATE_KEY_LP_HZ_MAX, OMX_GATE_KEY_LP_HZ_MIN);
  const struct omx_gate_controls c = {&enabled,  &s->key_external, &threshold_db, &ratio, &range_db,
                                      &attack_ms, &release_ms,      &hp,           &lp};
  omx_gate_resolve(&s->gate, &c, &s->atom);
  omx_gate_knee(&s->atom,
                omx_clamp_or(knee_start_db, OMX_GATE_KNEE_START_DB_MIN, OMX_GATE_KNEE_START_DB_MAX,
                             OMX_GATE_KNEE_START_DB_DEFAULT),
                omx_clamp_or(knee_end_db, OMX_GATE_KNEE_END_DB_MIN, OMX_GATE_KNEE_END_DB_MAX,
                             OMX_GATE_KNEE_END_DB_DEFAULT));
  s->atom.hold_frames = omx_dyn_hold_frames(
      omx_clamp_or(hold_ms, OMX_GATE_HOLD_MS_MIN, OMX_GATE_HOLD_MS_MAX, OMX_GATE_HOLD_MS_DEFAULT), s->sr);
  s->atom.hyst_db = omx_clamp_or(hysteresis_db, OMX_GATE_HYSTERESIS_DB_MIN, OMX_GATE_HYSTERESIS_DB_MAX,
                                 OMX_GATE_HYSTERESIS_DB_DEFAULT);
  const struct omx_dyn *p = &s->atom;
  (void)p; /* read only by the POST, compiled out of a release build */
  OMX_POST(p->gc.mode == OMX_DYN_BELOW && p->gc.ratio >= OMX_GATE_RATIO_MIN &&
               p->gc.ratio <= OMX_GATE_RATIO_MAX && p->gc.range_db >= OMX_GATE_RANGE_DB_MIN &&
               p->gc.range_db <= OMX_GATE_RANGE_DB_MAX &&
               p->gc.thresh_db >= OMX_GATE_THRESHOLD_DB_MIN &&
               p->gc.thresh_db <= OMX_GATE_THRESHOLD_DB_MAX && p->attack_ms >= OMX_GATE_ATTACK_MS_MIN &&
               p->attack_ms <= OMX_GATE_ATTACK_MS_MAX && p->attack_coeff >= 0.0f &&
               p->attack_coeff < 1.0f && p->release_coeff >= 0.0f && p->release_coeff < 1.0f &&
               p->hyst_db >= OMX_GATE_HYSTERESIS_DB_MIN && p->hyst_db <= OMX_GATE_HYSTERESIS_DB_MAX &&
               p->gc.knee_db >= 0.0f && p->knee_shift_db >= -0.5f * p->gc.knee_db &&
               p->knee_shift_db <= 0.5f * p->gc.knee_db && s->gate.key.hp_hz >= OMX_GATE_KEY_HP_HZ_MIN &&
               s->gate.key.hp_hz <= OMX_GATE_KEY_HP_HZ_MAX && s->gate.key.lp_hz >= OMX_GATE_KEY_LP_HZ_MIN &&
               s->gate.key.lp_hz <= OMX_GATE_KEY_LP_HZ_MAX,
           "atom-meets-the-kernel-preconditions");
}
#undef OMX_CONTRACT_STAGE

/**
 * @brief The frames of latency the instance reports for its current atom.
 * @param s The instance.
 * @return OMX_OVS_LATENCY_4X while 4x is engaged, else 0; 0 for a refused instance.
 * @note RT-safe. Thread-safe: pure in `s`.
 */
static inline float omx_gate_instance_latency(const OmxGateInstance *s) {
  return s && s->ready ? omx_gate_latency(&s->atom) : 0.0f;
}

/**
 * @brief THE AUDIO CALLBACK'S WHOLE SHARE: the block through `omx_gate_run` with the resolved atom.
 * @param s The instance.
 * @param key The sidechain block, or NULL (unconnected: the self-detecting gate).
 * @param in_l The left input block.
 * @param in_r The right input block.
 * @param out_l The left output block; may alias any input or the key.
 * @param out_r The right output block; may alias any input or the key.
 * @param n Frames.
 * @note RT-safe: no allocation, no lock. Not ready is the identity byte for byte. Thread-safe on
 *       distinct instances.
 */
static inline void omx_gate_instance_run(OmxGateInstance *s, const float *key, const float *in_l,
                                         const float *in_r, float *out_l, float *out_r, uint32_t n) {
  if (!in_l || !in_r || !out_l || !out_r || n == 0u) return;
  if (!s || !s->ready) {
    if (out_l != in_l) memmove(out_l, in_l, (size_t)n * sizeof(float));
    if (out_r != in_r) memmove(out_r, in_r, (size_t)n * sizeof(float));
    return;
  }
  omx_gate_run(&s->gate, &s->atom, key, &s->key_external, in_l, in_r, out_l, out_r, n);
}

#endif /* OMX_GATE_INSTANCE_H */
