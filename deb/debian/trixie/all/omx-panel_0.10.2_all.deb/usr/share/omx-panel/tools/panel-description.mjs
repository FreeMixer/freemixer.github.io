// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 Pau Aliagas <linuxnow@gmail.com>
/*
 * panel-description.mjs — a plugin's panel laid out from its DESCRIPTOR (omx-contract's descriptor
 * words: each control's kind, travel with its unit and scale, choice ids, label, group and meaning, the
 * ports, the origin), so a plugin from any origin gets a layout (docs/panel-layout.md). A declared
 * panel, ours, adds the family, the sections, the order, the roles, the widgets, the graphs and the
 * per-placement come-up values on top. The result is org.openmixer.panel-description/1:
 * the family, the sections in order, one control per listed parameter, the roles its family takes, a
 * display per section `graph` the extension names, and the canonical serialisation whose SHA-256 is
 * the fingerprint. omx-plugins writes the rows its faces serve from it (its include/omx_panel_description.h)
 * and reads what a built face serves back against it. The descriptor is the only input: a declaration is
 * rendered to its descriptor by its owner first.
 *
 * The vocabulary below is the extension's: its families, each family's roles with the units a role
 * accepts, and the displays a family draws in closed form. A declaration's role the family has no
 * place for, or whose parameter's unit the role does not take, is not published (a host would drop
 * it and the fingerprint would no longer be what it reads); the generated header names each one.
 */
import { createHash } from 'node:crypto';
import { easyOf } from './easy.mjs';
import { INDEXED_ROLES, ROLES } from './role-table.mjs';
import { meaningOfRole, servedToken } from './vocabulary.mjs';

export const PANEL_ID = 'org.openmixer.panel-description/1';

/** The extension's families, by enum value. */
export const FAMILIES = ['none', 'gate', 'dynamics', 'limiter', 'deesser', 'eq', 'filter', 'drive', 'modulation', 'delay', 'reverb', 'pitch'];

/** The widgets a face serves, by enum value. */
export const WIDGETS = ['auto', 'knob', 'fader', 'switch', 'selector'];

/** The standard widgets a panel picks from a descriptor; a representation (a skin) draws each. */
export const STANDARD_WIDGETS = ['knob', 'fader', 'switch', 'selector', 'meter', 'curve', 'xy', 'display'];
/** What a meter measures. */
export const MEASUREMENTS = ['peak', 'rms', 'vu', 'ppm', 'lufs'];
/** The units a read-only travel is a level meter in, and the measurement a unit itself names. */
const LEVEL_UNITS = ['dB', 'dBFS', 'dBu', 'LUFS'];
const MEASUREMENT_OF_UNIT = { LUFS: 'lufs' };
/** A declared panel's widget names -> the standard widget (`choice` is the older spelling of a selector). */
const DECLARED_WIDGET = { knob: 'knob', fader: 'fader', switch: 'switch', selector: 'selector', choice: 'selector' };
/** A standard widget -> the widget a face serves: a selector is AUTO (it needs CLAP_PARAM_IS_ENUM,
 * which the faces do not set), and so is any widget the extension has no value for. */
const SERVED_WIDGET = { knob: 'knob', fader: 'fader', switch: 'switch' };

/**
 * The standard widget control `c` (a descriptor control) is drawn with: `{ widget }`, a meter's with
 * its `measurement` (null when the descriptor does not state it), a trigger's switch `momentary`. A
 * declared widget wins; else a read-only travel in a level unit is a meter and any other read-only
 * control a display, a toggle or a trigger a switch, a choice a selector, a travel a knob.
 */
export function widgetOf(c, declared) {
  if (declared !== undefined) return { widget: DECLARED_WIDGET[declared] ?? declared };
  if (c.readonly) {
    const unit = c.travel?.unit;
    return LEVEL_UNITS.includes(unit) ? { widget: 'meter', measurement: MEASUREMENT_OF_UNIT[unit] ?? null } : { widget: 'display' };
  }
  if (c.kind === 'toggle') return { widget: 'switch' };
  if (c.kind === 'trigger') return { widget: 'switch', momentary: true };
  if (c.kind === 'choice') return { widget: 'selector' };
  return { widget: 'knob' };
}

/** The widget a face serves for a standard widget. */
export const servedWidget = (standard) => SERVED_WIDGET[standard] ?? 'auto';

/** The display kinds and sources, by enum value. */
export const DISPLAY_KINDS = ['gain_reduction_bar', 'transfer_curve', 'eq_response', 'meter'];
export const DISPLAY_SOURCES = ['family', 'meters', 'gain_adjustment', 'curve'];
export const PLACEMENTS = ['insert', 'return', 'bus', 'master'];

/** A section `graph` -> the display the extension names for it; a graph with none here is the
 * renderer's own (delay taps, a decay envelope, an LFO). */
const DISPLAY_OF_GRAPH = { 'eq-curve': 'eq_response', 'dynamics-curve': 'transfer_curve', 'transfer-curve': 'transfer_curve' };
/** The displays a host computes from a family's roles in closed form. */
const CLOSED_FORMS = { gate: ['transfer_curve'], dynamics: ['transfer_curve'], eq: ['eq_response'], drive: ['transfer_curve'] };

/** A descriptor unit -> the token a role checks it against: the param-contract extension's own table,
 * so a unit it serves is a unit a role can take. A unit it has no token for (`unknown` among them) is
 * a plain number and takes no role. */
export const unitToken = (unit) => servedToken(unit);

/** Each family's roles and the units each accepts, and the roles that repeat by index: tools/role-table.mjs's, the
 * one table, data a browser loads as it is. */
export { INDEXED_ROLES, ROLES };

/**
 * The meanings each family stands on, in the order inference tries them: `backs`, one of which a
 * declared family needs among its controls' meanings (null: none yet has a word, a rotor's speeds and
 * an LFO's shape have no meaning); `infer`, the sets of meanings any one of which, all present, makes
 * a plugin with no declared panel that family.
 */
export const FAMILY_MEANINGS = {
  limiter: { backs: ['ceiling'], infer: [['ceiling']] },
  deesser: { backs: ['frequency', 'threshold'], infer: [['frequency', 'threshold', 'listen']] },
  gate: { backs: ['threshold'], infer: [['threshold', 'range']] },
  dynamics: { backs: ['threshold', 'ratio'], infer: [['threshold', 'ratio']] },
  eq: { backs: ['gain', 'frequency'], infer: [['frequency', 'gain', 'q']] },
  filter: { backs: ['cutoffFrequency'], infer: [['cutoffFrequency']] },
  drive: { backs: ['drive'], infer: [['drive']] },
  delay: { backs: ['delay'], infer: [['delay', 'feedback']] },
  reverb: { backs: ['size', 'decay'], infer: [['size'], ['decay']] },
  pitch: { backs: ['shift'], infer: [['shift']] },
  modulation: { backs: null, infer: [['rate', 'depth']] },
};

/**
 * The family of a plugin whose controls are `controls` (descriptor controls): `{ family }`, and for a
 * declared family none of its controls' meanings backs, `{ family, needs }` naming what it lacks. With
 * no declared family, an effect takes the first family whose meanings it carries; an instrument, or a
 * plugin no family fits, is none.
 */
export function familyOf(controls, declared, features = []) {
  const have = new Set(controls.map((c) => c.meaning).filter(Boolean));
  if (declared !== undefined) {
    // the declaration's family is one of the extension's (the schema's $defs.family is the same closed
    // set); a family the extension has no place for is none: no house view
    const family = FAMILIES.includes(declared) ? declared : 'none';
    const backs = FAMILY_MEANINGS[family]?.backs;
    return backs && !backs.some((m) => have.has(m)) ? { family, needs: backs } : { family };
  }
  if (features.includes('instrument')) return { family: 'none' };
  for (const [family, { infer }] of Object.entries(FAMILY_MEANINGS)) if (infer.some((all) => all.every((m) => have.has(m)))) return { family };
  return { family: 'none' };
}

/** The roles of `family` that meaning `m` names: each role of the family whose meaning is `m`. */
const rolesOfMeaning = (family, m) => Object.keys(ROLES[family]).filter((role) => meaningOfRole(role) === m);

const KEY = /^[a-z][a-z0-9_]*(\.[a-z0-9_]+)*$/;
const KEY_MAX = 63, LABEL_MAX = 255;

/** camelCase -> snake_case, the key grammar's spelling of a symbol or section key. */
export const snake = (s) => s.replace(/([a-z0-9])([A-Z])/g, '$1_$2').toLowerCase();

/** A free text (a group's name) in the key grammar: snake_case, any other character an underscore. */
const keyOfText = (s) => {
  const k = snake(s).replace(/[^a-z0-9]+/g, '_').replace(/^_+|_+$/g, '');
  return /^[a-z]/.test(k) ? k : `s_${k}`;
};

/** A descriptor with no control to lay out (none stated, or every one hidden): there is no panel to make, and the
 * layout says so by code instead of answering an empty one. */
export class NoControls extends Error {
  code = 'PANEL_NO_CONTROLS';
}

/**
 * The key a layout names a control by: its symbol, else an LV2 control's id (its port symbol), else a CLAP
 * control's numeric id as `p<id>` (the id is the one thing a CLAP plugin keeps unique and stable, and a bare
 * number is not in the key grammar), else its name.
 */
export const keyOf = (c) => c.symbol ?? (typeof c.id === 'string' ? c.id : Number.isInteger(c.id) ? `p${c.id}` : c.name);

/** The ports a layout carries: the audio inputs and outputs with their channels, the side-chain, the notes in. */
function portsOf(ports = []) {
  const audio = (direction) => ports.filter((p) => p.kind === 'audio' && p.direction === direction).map((p) => ({ id: p.id, name: p.name, role: p.role ?? 'main', channels: p.channels ?? null }));
  return { inputs: audio('in'), outputs: audio('out'), sidechain: ports.some((p) => p.kind === 'audio' && p.direction === 'in' && p.role === 'sidechain'), notes: ports.some((p) => (p.kind === 'note' || p.kind === 'midi') && p.direction === 'in') };
}

/**
 * The panel of `descriptor`, of any origin. `panel` (a declaration's) gives the family, sections,
 * order, roles, widgets and graphs; with none, the sections are the controls' groups, the family the
 * one their meanings make and the roles the ones their meanings play. `ns` is the label-key namespace
 * (without one the label keys are null); `choiceUnits` and `byKind` are a declaration's extras.
 */
export function panelLayout(descriptor, { panel, ns, where = `descriptor ${descriptor.plugin?.id}`, choiceUnits = {}, byKind = {} } = {}) {
  const all = descriptor.controls;
  const byKey = new Map(all.map((c, i) => [keyOf(c), i]));
  const control = (sym) => all[byKey.get(sym)];
  const unitOf = (c) => c.travel?.unit ?? choiceUnits[keyOf(c)] ?? '';
  const key = (k, what) => {
    if (!KEY.test(k) || k.length > KEY_MAX) throw new Error(`${where}: ${what} '${k}' is not a key of ${PANEL_ID} ([a-z][a-z0-9_]*, dotted, at most ${KEY_MAX} bytes)`);
    return k;
  };
  const labelKey = (k, what) => (ns ? key(`${ns}.${k}`, what) : null);
  const label = (s, what) => {
    if (Buffer.byteLength(s) > LABEL_MAX) throw new Error(`${where}: ${what} label is longer than ${LABEL_MAX} bytes`);
    return s;
  };

  const { family, needs } = familyOf(all, panel ? panel.family : undefined, descriptor.plugin?.features);
  // a declared family stands on its controls' meanings: a transient designer is no compressor
  if (needs) {
    const have = [...new Set(all.map((c) => c.meaning).filter(Boolean))];
    throw new Error(`${where}: the ${family} family needs a control meaning ${needs.join(' or ')}, and its meanings are ${have.join(', ') || 'none'}: its family is none`);
  }

  // the sections, each with the controls it lists: the declared panel's, else one per group path
  let listed;
  if (panel) listed = panel.sections.map((s) => ({ key: snake(s.key), label: s.label, controls: s.controls, graph: s.graph }));
  else {
    const groups = new Map();
    for (const c of all) {
      if (c.hidden) continue;
      const path = c.group?.length ? c.group : ['Controls'];
      const k = path.map(keyOfText).join('.');
      if (!groups.has(k)) groups.set(k, { key: k, label: path.join(' / '), controls: [] });
      groups.get(k).controls.push(keyOf(c));
    }
    listed = [...groups.values()];
  }
  const sections = listed.map((s) => {
    const k = key(s.key, 'section key');
    return { key: k, labelKey: labelKey(`section.${k}`, 'section label key'), label: label(s.label, `section '${s.key}'`) };
  });
  if (new Set(sections.map((s) => s.key)).size !== sections.length) throw new Error(`${where}: two panel sections share a key`);
  for (const sym of Object.keys(panel?.visibleWhen ?? {})) if (!listed.some((s) => s.controls.includes(sym))) throw new Error(`${where}: visibleWhen names '${sym}', which no panel section lists`);

  // the declared visibility: each governed control's governing parameter (its id, as the ABI's visible_param_id) and
  // the mask of the values that show it, bit v for value v
  const visibility = new Map(Object.entries(panel?.visibleWhen ?? {}).map(([sym, rule]) => [sym, visibilityOf(sym, rule, control, where)]));
  const seen = new Set();
  const controls = listed.flatMap((s, section) =>
    s.controls.map((sym) => {
      const c = control(sym);
      if (!c) throw new Error(`${where}: panel section '${s.key}' lists '${sym}', no parameter`);
      if (seen.has(sym)) throw new Error(`${where}: '${sym}' is a control twice`);
      seen.add(sym);
      const shown = visibility.get(sym);
      const standard = widgetOf(c, panel?.widgets?.[sym]);
      if (standard.widget === 'switch' && c.kind !== 'toggle' && c.kind !== 'trigger') throw new Error(`${where}: '${sym}' is drawn as a switch and is not a toggle`);
      return {
        symbol: sym, param: c.id, section, sectionKey: sections[section].key, widget: servedWidget(standard.widget), standard,
        labelKey: labelKey(snake(sym), 'control label key'), label: label(c.label ?? c.name, `'${sym}'`), visible: shown?.visible ?? null, mask: shown?.mask ?? 0n,
        unit: unitOf(c), meaning: c.meaning ?? null,
        // what a renderer and the page cut read the mask against: the governing control's symbol and its come-up value
        ...(shown ? { visibleWhen: { symbol: shown.symbol, default: shown.default } } : {}),
        // the group is read by the page cut only: it stays out of the JSON and the canonical form
        ...(c.group?.length ? { [GROUP]: c.group.join(' / ') } : {}),
      };
    }),
  );

  const table = ROLES[family];
  const roles = [], unpublished = [];
  const bind = (role, index, sym) => {
    const c = control(sym);
    if (!c) throw new Error(`${where}: role '${role}' names '${sym}', no parameter`);
    const unit = unitOf(c);
    if (!table[role]) unpublished.push({ role, symbol: sym, why: `not a role of the ${family} family` });
    else if (!table[role].includes(unitToken(unit))) unpublished.push({ role, symbol: sym, why: `the ${role} role takes ${table[role].join(', ')}, not ${unit || 'no unit'}` });
    else roles.push({ role, index, symbol: sym, param: c.id, unit });
  };
  if (panel) {
    // an indexed role (an EQ band's) names every band's symbol in order: one row per band, its index the band's
    for (const [role, syms] of Object.entries(panel.roles ?? {})) [syms].flat().forEach((sym, index) => bind(role, index, sym));
  } else {
    // each meaning plays the one role of the family it names; an indexed role takes every control of
    // its meaning, any other its first, and a second is named
    const played = new Map();
    for (const c of all) {
      if (c.hidden || c.readonly || !c.meaning) continue;
      const named = rolesOfMeaning(family, c.meaning);
      if (named.length !== 1) continue;
      const [role] = named;
      const n = played.get(role) ?? 0;
      if (n && !INDEXED_ROLES.includes(role)) unpublished.push({ role, symbol: keyOf(c), why: `the ${role} role is played by ${roles.find((r) => r.role === role)?.symbol ?? 'another control'}` });
      else bind(role, n, keyOf(c));
      played.set(role, n + 1);
    }
  }

  const displays = listed.flatMap((s, section) => {
    const kind = DISPLAY_OF_GRAPH[s.graph];
    if (!kind) return [];
    if (!CLOSED_FORMS[family]?.includes(kind)) throw new Error(`${where}: section '${s.key}' draws ${s.graph}, and the ${family} family has no ${kind} a host computes`);
    return [{ kind, section, sectionKey: sections[section].key, source: 'family', meters: [null, null], curve: null, floor: null, labelKey: labelKey(`display.${kind}`, 'display label key'), label: label(s.label, `section '${s.key}'`) }];
  });

  // the contract's per-kind defaults: each channel kind the placement it is, the value inside the travel
  const defaults = all.flatMap((c, i) =>
    Object.entries(byKind[keyOf(c)] ?? {}).map(([kind, value]) => {
      const placement = PLACEMENT_OF_KIND[kind];
      if (!placement) throw new Error(`${where}: '${keyOf(c)}' comes up differently on a ${kind} channel, which has no placement of ${PANEL_ID}; add it to PLACEMENT_OF_KIND`);
      const [min, max] = c.travel ? [c.travel.min, c.travel.max] : c.values ? [Math.min(...c.values), Math.max(...c.values)] : [0, 1];
      const integer = c.kind !== 'travel' || c.travel.step === 1;
      if (!(value >= min && value <= max) || (integer && !Number.isInteger(value))) throw new Error(`${where}: '${keyOf(c)}' on ${kind} comes up at ${value}, outside its travel`);
      return { placement, symbol: keyOf(c), param: i, value };
    }),
  );

  if (controls.length === 0) {
    const listsPrograms = ['programs', 'presets'].map((k) => [k, descriptor[k]]).find(([, v]) => Array.isArray(v) && v.length > 0);
    throw new NoControls(`${where}: no control to lay out (${all.length === 0 ? 'the descriptor states no controls' : `its ${all.length} controls are all hidden`})${listsPrograms ? `; its ${listsPrograms[1].length} ${listsPrograms[0]} are not drawn, a program list is not a control` : ''}`);
  }
  // The Easy face: a view of the panel, so it stays out of the canonical form and the fingerprint
  const easy = easyOf({ family, roles, controls }, { declared: panel?.easy ?? descriptor.easy, where });
  return { origin: descriptor.origin, family, sections, controls, roles, unpublished, displays, defaults, ports: portsOf(descriptor.ports), easy };
}

/** The highest value a visibility mask has a bit for: the ABI's visible_mask is 64 bits. */
export const VISIBLE_MAX = 63;
const ALL_BITS = (1n << BigInt(VISIBLE_MAX + 1)) - 1n;

/** The integer a control holds at come-up, or undefined for one that holds no integer (a travel that is not whole). */
function integerDefault(c) {
  if (c.kind === 'toggle') return c.default ? 1 : 0;
  if (c.kind === 'choice' && Array.isArray(c.values)) {
    const at = (c.ids ?? []).indexOf(c.default);
    return at >= 0 ? c.values[at] : Number.isInteger(c.default) ? c.default : c.values[0];
  }
  if (c.kind === 'travel' && c.travel?.step === 1) return c.travel.default ?? c.travel.min;
  return undefined;
}

/** The mask of a visibility rule: `values` sets bit v for each value v; `atLeast: n` sets bits n..63 (a count: band n
 * shows while the count is n or more). */
export function visibilityMask(rule) {
  if (rule.atLeast !== undefined) return ALL_BITS ^ ((1n << BigInt(rule.atLeast)) - 1n);
  return rule.values.reduce((m, v) => m | (1n << BigInt(v)), 0n);
}

/** A declared `visibleWhen` entry for control `sym`, checked: `{ param, values }` or `{ param, atLeast }`, its param an
 * integer or toggle control of the plugin, every value inside 0..63. */
function visibilityOf(sym, rule, control, where) {
  const what = `visibleWhen of '${sym}'`;
  if (rule === null || typeof rule !== 'object' || typeof rule.param !== 'string') throw new Error(`${where}: ${what} names no param`);
  const hasValues = rule.values !== undefined, hasAtLeast = rule.atLeast !== undefined;
  if (hasValues === hasAtLeast) throw new Error(`${where}: ${what} states one of values or atLeast`);
  const inRange = (v) => Number.isInteger(v) && v >= 0 && v <= VISIBLE_MAX;
  if (hasValues && (!Array.isArray(rule.values) || rule.values.length === 0 || !rule.values.every(inRange))) throw new Error(`${where}: ${what}: values are integers 0..${VISIBLE_MAX}`);
  if (hasAtLeast && !inRange(rule.atLeast)) throw new Error(`${where}: ${what}: atLeast is an integer 0..${VISIBLE_MAX}`);
  if (rule.param === sym) throw new Error(`${where}: ${what} is governed by itself`);
  const g = control(rule.param);
  if (!g) throw new Error(`${where}: ${what} names '${rule.param}', no parameter`);
  const def = integerDefault(g);
  if (def === undefined) throw new Error(`${where}: ${what} names '${rule.param}', which is not an integer or toggle parameter`);
  return { symbol: rule.param, visible: g.id, mask: visibilityMask(rule), default: def };
}

/** The checked visibility rules of a declared panel over `descriptor`: control symbol -> `{ symbol, visible, mask,
 * default }`, the governing control's symbol and id, the mask, and the governing control's come-up value. */
export function visibilityRules(descriptor, visibleWhen = {}, where = `descriptor ${descriptor.plugin?.id}`) {
  const all = descriptor.controls ?? [];
  const control = (sym) => all.find((c) => keyOf(c) === sym);
  return new Map(Object.entries(visibleWhen).map(([sym, rule]) => [sym, visibilityOf(sym, rule, control, where)]));
}

/** Whether control `c` of a layout is shown while the controls read `values` (symbol -> value; a governing control left
 * out reads its come-up value). A control with no visibility rule is always shown. */
export function isVisible(c, values = {}) {
  if (c.visible === null || c.visible === undefined) return true;
  const v = values[c.visibleWhen.symbol] ?? c.visibleWhen.default;
  // a layout read back from its JSON carries the mask as hex
  const mask = typeof c.mask === 'string' ? BigInt(`0x${c.mask}`) : BigInt(c.mask);
  return Number.isInteger(v) && v >= 0 && v <= VISIBLE_MAX && ((mask >> BigInt(v)) & 1n) === 1n;
}

/** A channel kind whose default a contract travel states (byKind) -> the placement it is. */
const PLACEMENT_OF_KIND = { fxReturn: 'return', main: 'master' };

/** The key a control carries its declared group under, for the page cut: a symbol, so no serialisation sees it. */
export const GROUP = Symbol('group');

/** The name of the Easy controls' page and of a MOD GUI's first section. */
export const EASY_PAGE = 'Easy';

/** The surface's slots per page, CLAP_REMOTE_CONTROLS_COUNT. */
export const PAGE_SIZE = 8;

/** The pages of clap.remote-controls/2 by the page rule: each section's controls in order, cut into
 * pages of `perPage` (default eight, the surface's slots), a section of several pages numbering them; a
 * short page's slots are null. With `perPage` stated, a group that fits a page is not split across two
 * (a page ends early to keep it whole; a group wider than a page is cut), and a section of several
 * pages names each page by the controls it holds, "Band: Freq - Q". Left out, the cut is the plain one.
 * With `easyFirst` the Easy controls come first, on pages of their own named Easy, Easy 2, and do not repeat.
 * A control hidden by `values` (symbol -> current value; a governing control left out reads its come-up value) takes
 * no slot, and a section left with none has no page: a host cuts again when a governing value changes. */
export function pagesOf(x, { perPage, easyFirst = false, values = {} } = {}) {
  const size = perPage ?? PAGE_SIZE;
  if (!Number.isInteger(size) || size < 1) throw new Error(`pages: --per-page must be a whole number of at least 1, not ${perPage}`);
  // a control the current values hide takes no slot: the pages are a function of the governing values
  const shown = x.controls.filter((c) => isVisible(c, values));
  x = { ...x, controls: shown };
  const easy = (easyFirst ? x.easy : []).filter((symbol) => shown.some((c) => c.symbol === symbol));
  const easyPages = [];
  for (let k = 0; k < easy.length; k += size) {
    const ids = easy.slice(k, k + size).map((symbol) => x.controls.find((c) => c.symbol === symbol).param);
    while (ids.length < size) ids.push(null);
    easyPages.push({ section: null, sectionName: EASY_PAGE, pageName: k === 0 ? EASY_PAGE : `${EASY_PAGE} ${k / size + 1}`, ids });
  }
  return [...easyPages, ...x.sections.flatMap((s, section) => {
    const cs = x.controls.filter((c) => c.section === section && !easy.includes(c.symbol));
    const pages = [];
    if (perPage === undefined) for (let k = 0; k < cs.length; k += size) pages.push(cs.slice(k, k + size));
    else {
      let page = [];
      for (let i = 0; i < cs.length; ) {
        let j = i + 1;
        while (j < cs.length && cs[j][GROUP] === cs[i][GROUP]) j++;
        const run = cs.slice(i, j);
        i = j;
        if (run.length <= size && page.length + run.length > size) { pages.push(page); page = []; }
        for (const c of run) {
          if (page.length === size) { pages.push(page); page = []; }
          page.push(c);
        }
      }
      if (page.length) pages.push(page);
    }
    return pages.map((page, k) => {
      const ids = page.map((c) => c.param);
      while (ids.length < size) ids.push(null);
      const held = page.length > 1 ? `${page[0].label} - ${page[page.length - 1].label}` : page[0].label;
      const pageName = pages.length === 1 ? s.label : perPage === undefined ? `${s.label} ${k + 1}` : `${s.label}: ${held}`;
      return { section, sectionName: s.label, pageName, ids };
    });
  })];
}

/** The shortest decimal that round-trips to the same binary64, -0 written 0. */
const shortest = (n) => (Object.is(n, -0) ? '0' : String(n));
const byCodeUnit = (a, b) => (a < b ? -1 : a > b ? 1 : 0);

/** The canonical serialisation: UTF-8, LF after every line, TAB-separated, parameters by symbol, the
 * fallback labels left out. */
export function panelCanonical(x) {
  const lines = [PANEL_ID, `family\t${x.family}`];
  x.sections.forEach((s, i) => lines.push(['section', i, s.key, s.labelKey].join('\t')));
  for (const c of x.controls) lines.push(['control', c.symbol, c.sectionKey, c.widget, c.labelKey, c.visible ?? '-', c.mask.toString(16)].join('\t'));
  for (const r of [...x.roles].sort((a, b) => byCodeUnit(a.role, b.role) || a.index - b.index)) lines.push(['role', r.role, r.index, r.symbol].join('\t'));
  for (const v of x.displays) {
    const floor = v.floor === null ? '-' : typeof v.floor === 'number' ? shortest(v.floor) : v.floor;
    const meter = (m) => (m === null ? '-' : String(m));
    lines.push(['display', v.kind, v.sectionKey, v.source, meter(v.meters[0]), meter(v.meters[1]), v.curve ?? '-', floor, v.labelKey].join('\t'));
  }
  const order = (p) => PLACEMENTS.indexOf(p);
  for (const p of [...x.defaults].sort((a, b) => order(a.placement) - order(b.placement) || byCodeUnit(a.symbol, b.symbol))) lines.push(['default', p.placement, p.symbol, shortest(p.value)].join('\t'));
  return `${lines.join('\n')}\n`;
}

/** The fingerprint: lowercase hex SHA-256 of the canonical serialisation. */
export const panelFingerprint = (x) => createHash('sha256').update(panelCanonical(x)).digest('hex');
