/**
 * A descriptor control as the travel this generator draws: `{ kind, min, max, def, points? }`, `kind` `toggle`
 * (0..1), `integer` (a choice, or a travel of step 1) or none (a continuous travel); a choice's `points` are its
 * values and labels, `{value, label}` from the lowest. Undefined for a control with no travel to draw (a trigger,
 * a text, a read-only reading).
 */
export function travelOf(c: any): {
    kind: string;
    min: any;
    max: any;
    def: any;
    points: any;
} | {
    min: any;
    max: any;
    def: any;
    kind?: string | undefined;
    points?: undefined;
} | undefined;
/**
 * The widget a declared parameter takes when its panel names none: a toggle is a switch; a parameter with
 * labelled values (a choice, an enumeration port) or an integer with a few steps is a selector,
 * MOD's own `custom-select` over the port's values; an integer with a wide travel (more than
 * MAX_SELECTOR_STEPS steps, e.g. a time in ms) and every other travel is a knob.
 */
export function widgetOf(p: any): "knob" | "switch" | "selector";
/**
 * Whether `widget` can draw `p`: a switch a toggle; a selector an integer travel (every step an
 * option); a knob or a fader a travel with no labelled values (labels are a selector's) and no toggle.
 */
export function widgetFits(widget: any, p: any): boolean;
/** The widget a control of `panel` is drawn with: the panel's `widgets` entry, else widgetOf. */
export function widgetFor(panel: any, symbol: any, p: any): any;
/** A selector's options, `{value, label}` from min up: the labelled values, else every step. */
export function optionsOf(p: any): any;
/** Where a value sits on its travel, 0..1 (every declared travel is linear). */
export function travelFraction(p: any, v: any): number;
/** The panel a descriptor is drawn with: the declared one, else the layout's sections and family over its
 * groups and meanings (tools/panel-description.mjs). */
export function panelOf(descriptor: any, declared: any): any;
/** The panel of a descriptor, resolved: each section with its controls, each control its descriptor control's
 * symbol, name and travel. `stem` names the files. */
export function resolvePanel(descriptor: any, { panel: declared, stem }: {
    panel: any;
    stem: any;
}): {
    uri: any;
    stem: any;
    name: any;
    brand: any;
    family: any;
    sections: any;
};
/** Every box of the face, in px at scale 1: what the template positions and the raster paints. */
export function layout(panel: any): {
    w: number;
    h: any;
    sections: any;
};
/** The look: tools/look.json, every colour a plain #rrggbb. */
export function loadLook(): {
    theme: any;
    personality: any;
    tokens: {};
};
/** The face at `scale`, every control at its declared default. */
export function renderFace(lay: any, tok: any, scale: any): Buffer<ArrayBuffer>;
/** MOD's film strip: `filmFrames` square frames left to right, the knob from minimum to maximum. */
export function renderFilm(tok: any): Buffer<ArrayBuffer>;
/** The fader's film strip: the same square frames, the fader from minimum to maximum. */
export function renderFaderFilm(tok: any): Buffer<ArrayBuffer>;
/** `modgui.ttl`: the gui resource, and `modgui:port` for every input control of the FIRST section (a readout is
 * none); a modgui:port's lv2:index is its order on the pedal, its symbol and name the LV2 port's. */
export function emitModguiTtl(panel: any, source: any): string;
/** The icon template, in MOD's documented format: every section and every control, laid out. */
export function emitTemplate(panel: any, lay: any, source: any): string;
/** The stylesheet: the GEOMETRY and the look's resolved tokens, scoped by MOD's {{{cns}}}. */
export function emitStylesheet(panel: any, look: any, source: any): string;
/** Every file of a descriptor's modgui, as [path relative to the LV2 bundle, bytes], in a fixed order. `source`
 * is what the banner names the files were made from. */
export function generateModgui(descriptor: any, { panel: declared, stem, source }: {
    panel: any;
    stem: any;
    source: any;
}, look?: {
    theme: any;
    personality: any;
    tokens: {};
}): (string | Buffer<ArrayBuffer>)[][];
export function main(argv: any): void;
export { LOOK_JSON };
/** The shared widgets, schema/panel.schema.json's `$defs.widget`: the one list a plugin's schema, this generator
 * and the console name a control's widget from. */
export const WIDGETS: any;
export const MODGUI_TTL: "modgui.ttl";
export const MODGUI_DIR: "modgui";
/** An integer travel with more steps than this is a continuous knob; fewer is a selector. */
export const MAX_SELECTOR_STEPS: 16;
/** The controls of one row of a section; a section with more wraps onto further rows. */
export const ROW_CONTROLS: 8;
/** The geometry, in CSS px: one set of numbers the template, the stylesheet and the raster read. */
export const GEOMETRY: Readonly<{
    pad: 16;
    headH: 40;
    sectionTop: 52;
    sectionGap: 10;
    sectionPad: 8;
    sectionTitleH: 18;
    cellW: 72;
    cellH: 76;
    knob: 48;
    knobTop: 4;
    switchW: 40;
    switchH: 20;
    switchTop: 18;
    selectorW: 64;
    selectorH: 22;
    selectorTop: 17;
    faderW: 14;
    faderCap: 10;
    radius: 10;
    sectionRadius: 6;
    filmFrames: 65;
    thumbScale: 0.5;
}>;
export function lookTokens(): {};
import { LOOK_JSON } from './look.mjs';
