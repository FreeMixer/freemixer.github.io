/** `#rrggbb` -> [r, g, b]. A token that is not a plain hex colour is refused, never guessed. */
export function rgbOf(hex: any): number[];
export function canvas(w: any, h: any): {
    w: any;
    h: any;
    data: Uint8Array<ArrayBuffer>;
};
/** A rectangle with rounded corners of radius `r`. */
export function roundRect(c: any, x: any, y: any, w: any, h: any, r: any, rgb: any): void;
/** A filled disc. */
export function disc(c: any, cx: any, cy: any, r: any, rgb: any): void;
/** A segment of half-width `hw` with round caps. */
export function segment(c: any, ax: any, ay: any, bx: any, by: any, hw: any, rgb: any): void;
/** One fixed-Huffman deflate block over `raw`, matching only at the `distances` given, greedily. */
export function deflateFixed(raw: any, distances: any): Uint8Array<ArrayBuffer>;
/** The scanlines PNG compresses: filter byte 0 (None) then the row's RGBA. */
export function scanlines(c: any): Uint8Array<ArrayBuffer>;
/** A PNG (8-bit RGBA) of the canvas. `period` is a horizontal repeat in pixels worth matching (a
 * film strip's frame width); the matcher also tries the previous pixel and the previous row. */
export function encodePng(c: any, period?: number): Buffer<ArrayBuffer>;
export function snap(v: any): number;
