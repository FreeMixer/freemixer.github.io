/** The installed omx-contract schema, where the descriptor words are declared. */
export function contractSchemaFile(): string | undefined;
/** The meaning role `role` plays, or undefined when the descriptor has no word for it. */
export function meaningOfRole(role: any): any;
/** A descriptor unit's token: the LV2 unit a face writes for it (units:db -> db, urn:openmixer:unit#dBFS -> dbfs), else
 * the name of a vendor-block unit it is (dBu -> dbu), else undefined. */
export function unitTokenOf(unit: any): any;
/** The token of a unit the param-contract extension serves (one with a header value, or "" for none), else undefined. */
export function servedToken(unit: any): any;
/** Every unit plugin-hostd's LV2 table maps, and "", with its contract unit: `{ <unit>: [token, header value] }`, a unit
 * the header has no value for `['none', 0]`. */
export function contractUnits(): {
    [k: string]: any[];
};
/** The descriptor file a package installed into omx-contract's contract directory, `<package>/<name>`:
 * `<contractdir>/3/<package>/plugins/<name>.json`. */
export function installedDescriptorFile(ref: any): string;
export function meanings(): any;
/** A panel role -> the descriptor meaning it plays, where the two names differ. A role whose name is
 * a meaning plays that meaning; a role in neither has no meaning word and is bound only by a panel. */
export const MEANING_OF_ROLE: Readonly<{
    mix: "wetDryRatio";
    time: "delay";
    cutoff: "cutoffFrequency";
    band_freq: "frequency";
    band_gain: "gain";
    band_q: "q";
    hpf_freq: "lowCut";
    low_cut: "lowCut";
    lpf_freq: "highCut";
    high_cut: "highCut";
    hpf_slope: "slope";
    lpf_slope: "slope";
    key_listen: "listen";
}>;
export function lv2UnitTable(): any;
export function headerUnits(): any;
