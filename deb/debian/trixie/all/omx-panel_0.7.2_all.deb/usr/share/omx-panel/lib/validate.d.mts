/** The schema as the file holds it. */
export function loadSchema(path?: string): any;
/** A validator over `schema` (the file's own by default). `validateSkin(doc)` returns `{ ok, errors }`, each error `{ path, code, message }`, `code` the Ajv keyword that refused (`required`, `pattern`, ...). */
export function makeValidator(schema?: any): (doc: any) => {
    ok: boolean;
    errors: any;
};
export const SCHEMA_PATH: string;
export function validateSkin(doc: any): {
    ok: boolean;
    errors: any;
};
