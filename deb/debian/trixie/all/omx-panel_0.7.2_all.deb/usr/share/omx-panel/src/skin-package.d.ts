/** The panel families (§4), tools/panel-description.mjs's list. */
export declare const PANEL_FAMILIES: readonly string[];
export type PanelFamily = string;
/** The display kinds and sources (§3c), tools/panel-description.mjs's lists. */
export declare const PANEL_DISPLAY_KINDS: readonly string[];
export declare const PANEL_DISPLAY_SOURCES: readonly string[];
export type PanelDisplayKind = string;
export type PanelDisplaySource = string;
/** The widgets a face serves for a control (§3c), tools/panel-description.mjs's list. */
export declare const PANEL_WIDGETS: readonly string[];
export type PanelWidget = string;
/** The contract facts of one numeric parameter (§3f): a unit as its contract token (`ms`, `db`, `none`). */
export interface ServedNumberParam {
    readonly kind: 'number';
    readonly symbol: string;
    readonly name: string;
    readonly unit: string;
    readonly unitText?: string;
    readonly scale: 'linear' | 'log' | 'stepped';
    readonly step: number;
    readonly min?: number;
    readonly max?: number;
    readonly default: number;
    readonly enumLabels?: readonly string[];
}
/** A text parameter (§3f): an LV2 `atom:Path` (`path`) or `atom:String` (`text`) patch parameter. */
export interface ServedTextParam {
    readonly kind: 'path' | 'text';
    readonly symbol: string;
    readonly name: string;
    readonly default: string;
}
/** A momentary parameter (§3f, LV2 `pprops:trigger`): pressed it reads `max`, released `min`. */
export interface ServedTriggerParam {
    readonly kind: 'trigger';
    readonly symbol: string;
    readonly name: string;
    readonly min: number;
    readonly max: number;
}
/** One parameter of the description: a number with its contract facts, a trigger, or a path or text. */
export type ServedParam = ServedNumberParam | ServedTriggerParam | ServedTextParam;
/** Whether `p` is a numeric parameter: the only kind a role, a condition or a travel names. */
export declare function isNumberParam(p: ServedParam | undefined): p is ServedNumberParam;
export interface PanelSection {
    readonly key: string;
    readonly labelKey: string;
    /** Fallback text; never fingerprinted. */
    readonly label: string;
}
export interface PanelVisibleWhen {
    readonly param: string;
    readonly values: readonly number[];
}
export interface PanelControl {
    readonly symbol: string;
    /** The section's key. */
    readonly section: string;
    readonly widget: PanelWidget;
    readonly labelKey: string;
    readonly label: string;
    readonly visibleWhen: PanelVisibleWhen | null;
}
export interface PanelRole {
    readonly role: string;
    readonly index: number;
    readonly symbol: string;
    /** A band's fixed shape when no `band_type` parameter selects it (§4 "eq"). */
    readonly shape?: string;
}
export interface PanelDisplay {
    readonly kind: PanelDisplayKind;
    readonly section: string;
    readonly source: PanelDisplaySource;
    readonly meterIds: readonly [number | null, number | null];
    readonly curveIndex: number | null;
    /** GAIN_REDUCTION_BAR: a floor parameter's symbol, or a fixed floor in dB; null for a kind with no floor. */
    readonly floor: {
        readonly param: string;
    } | {
        readonly db: number;
    } | null;
    readonly labelKey: string;
    readonly label: string;
}
/** What an override applies to: the fields of a panel description it reads and replaces (§3f). */
export interface SkinDescription {
    readonly family: PanelFamily;
    /** Every parameter of the contract, in its id order. */
    readonly params: readonly ServedParam[];
    readonly sections: readonly PanelSection[];
    readonly controls: readonly PanelControl[];
    readonly roles: readonly PanelRole[];
    readonly displays: readonly PanelDisplay[];
}
/** Why D6 dropped a role entry (§3d): the rest of the description stands. */
export type RoleDropReason = 'role-not-in-family' | 'role-repeats' | 'role-unit' | 'unknown-symbol';
/** A D6 check over a list of role entries: the survivors in order, and each dropped one with its reason. */
export type SkinRoleCheck = (family: PanelFamily, roles: readonly PanelRole[], params: readonly ServedParam[]) => {
    readonly roles: readonly PanelRole[];
    readonly dropped: readonly {
        readonly role: PanelRole;
        readonly reason: RoleDropReason;
    }[];
};
/**
 * D6 over tools/panel-description.mjs's `ROLES`: each entry whose role is not in the family's table (or repeats by
 * index when the role is not an indexed one), whose parameter is unknown or not a number, whose unit token the role
 * does not take, or whose `(role, index)` repeats is dropped and named; the survivors keep their order.
 */
export declare const checkSkinRoles: SkinRoleCheck;
/** The refusal codes of the skin package and its importer, each with named arguments (docs/skin-package.md). */
export declare const SKIN_REFUSAL_CODES: readonly ["SKIN_OVERRIDE_INVALID", "SKIN_OVERRIDE_ENTRY_DROPPED", "SKIN_API_MISMATCH", "SKIN_VIEW_ERROR", "SKIN_VIEW_LINT", "MODGUI_NOT_FOUND", "MODGUI_TTL_INVALID", "MODGUI_NO_LICENCE", "MODGUI_LICENCE_UNMAPPED", "MODGUI_LICENCE_REFUSED", "MODGUI_UNKNOWN_PROPERTY", "MODGUI_PORT_UNKNOWN", "MODGUI_IMAGE_NOT_FOUND", "MODGUI_PATH_ESCAPE", "MODGUI_TARGET_EXISTS", "SKIN_MODGUI_LICENCE"];
export type SkinRefusalCode = (typeof SKIN_REFUSAL_CODES)[number];
/** A refusal: the code plus the named parameters a client needs to render or act on it. */
export interface Refusal {
    readonly code: SkinRefusalCode;
    readonly args?: Readonly<Record<string, string | number>>;
}
/** The path prefix the console serves skin packages under (§6.5), beside `MANUAL_MOUNT`. */
export declare const SKIN_MOUNT = "/skins";
/** The skin API version this console implements (§7.1). */
export declare const SKIN_API_VERSION = "1.1";
/** The override file's name inside a package (§6.2). */
export declare const SKIN_OVERRIDE_FILE = "skin.json";
/**
 * The one modgui licence allow-list (§6.6, §6.7): the importer refuses a bundle outside it at
 * import, and this console refuses it again at resolve time, because `skin.json` is itself
 * editable after import. ONE array both read; never a second copy under a second name.
 */
export declare const SKIN_LICENCE_ALLOW_LIST: readonly ["GPL-2.0-or-later", "GPL-3.0-or-later", "LGPL-2.1-or-later", "LGPL-3.0-or-later", "MIT", "BSD-2-Clause", "BSD-3-Clause", "ISC", "Zlib", "CC0-1.0", "CC-BY-4.0"];
/** The override file's one schema version (§6.3); another value refuses the file. */
export declare const SKIN_OVERRIDE_SCHEMA = 1;
/** Where a package is looked up, first found wins whole (§6.5, §12 Q4). */
export declare const SKIN_LEVELS: readonly ["config", "omx-plugins", "builtin"];
export type SkinLevel = (typeof SKIN_LEVELS)[number];
/** Level 1, under `xdgConfigHome()`. */
export declare const SKIN_CONFIG_SUBDIR = "openmixer/skins";
/** Level 2: installed with omx-plugins (`%{_datadir}/omx-plugins/skins`). */
export declare const OMX_PLUGINS_SKIN_INSTALL_DIR = "/usr/share/omx-plugins/skins";
/** Level 3: the built-in defaults installed with openmixer, as the manual is. */
export declare const OPENMIXER_SKIN_INSTALL_DIR = "/usr/share/openmixer/skins";
/**
 * The §7.2 version rule: accepted when the majors are equal and the view's minor is not above the
 * console's. A string that is not `MAJOR.MINOR` is not accepted.
 */
export declare function acceptsSkinApi(declared: string, supported?: string): boolean;
/**
 * A plugin id as a directory name (§6.1): kept as it is when it holds only `[A-Za-z0-9._-]`, else
 * every byte outside that set percent-encoded (RFC 3986, the unreserved set kept). `.` and `..` are
 * never a name: their dots are encoded. The ONE function the server, the importer and the
 * generator call.
 */
export declare function encodeSkinId(id: string): string;
/** The plugin id a directory name encodes, or null for a name {@link encodeSkinId} never writes. */
export declare function decodeSkinId(name: string): string | null;
/** Where a package came from (§6.3). */
export interface SkinSource {
    readonly kind: 'own' | 'generated' | 'modgui';
    readonly bundle?: string;
    readonly licenceEvidence?: string;
    /**
     * `kind: 'modgui'` only (§6.6): the bundle's own icon template and stylesheet, paths inside the
     * package's `modgui/` directory, so the modgui house view draws the plugin's OWN markup — the
     * bundle's images and layout, never our generic grid — instead of restating it as sections.
     */
    readonly modgui?: {
        readonly html: string;
        readonly css: string;
    };
}
export interface SkinOverrideSection {
    readonly key: string;
    readonly labelKey?: string;
    readonly label?: string;
    readonly controls: readonly string[];
}
/** The override file, parsed and schema-checked (§6.3). Symbols are checked when it is applied. */
export interface SkinOverride {
    readonly schema: typeof SKIN_OVERRIDE_SCHEMA;
    readonly plugin: string;
    readonly licence: string;
    readonly source?: SkinSource;
    readonly fingerprint?: string;
    readonly family?: PanelFamily;
    readonly roles?: Readonly<Record<string, string>>;
    readonly sections?: readonly SkinOverrideSection[];
    readonly labels?: Readonly<Record<string, {
        readonly labelKey?: string;
        readonly label?: string;
    }>>;
    readonly visibleWhen?: Readonly<Record<string, {
        readonly param: string;
        readonly values: readonly number[];
    }>>;
    readonly displays?: readonly PanelDisplay[];
    readonly houseView?: PanelFamily;
    readonly look?: string;
    readonly backdrop?: string;
    readonly view?: {
        readonly entry: string;
        readonly api: string;
    };
    /** The sandboxed iframe tier's opt-in (§6.7): presence alone opts a plugin in. */
    readonly modgui?: {
        readonly entry: string;
    };
}
/** The override file's text, parsed and schema-checked against the directory's decoded id (§6.3). */
export declare function parseSkinOverride(text: string, dirId: string): {
    readonly ok: true;
    readonly override: SkinOverride;
} | {
    readonly ok: false;
    readonly refusal: Refusal;
};
/** An override entry the application dropped, and why; the rest of the file stands (§6.3). */
export interface SkinDroppedEntry {
    readonly field: 'roles' | 'sections' | 'labels' | 'visibleWhen' | 'displays';
    readonly entry: string;
    readonly reason: RoleDropReason | 'unknown-symbol' | 'unknown-section';
}
/**
 * The override applied to a description, field by field as §6.3's table says, every symbol checked
 * against the contract (`params`): an unknown one drops that entry, D6 drops a role (`checkRoles`,
 * `checkSkinRoles` unless the caller passes its own); with no description, the override's `sections`
 * make one. The ONE function every caller applies it with.
 */
export declare function applySkinOverride<D extends SkinDescription>(description: D, override: SkinOverride, checkRoles?: SkinRoleCheck): {
    readonly description: D;
    readonly dropped: readonly SkinDroppedEntry[];
};
/** The words the view lint refuses (§7.3): an accident catcher, NOT a security control. */
export declare const SKIN_VIEW_LINT_WORDS: readonly ["fetch", "XMLHttpRequest", "WebSocket", "EventSource", "localStorage", "sessionStorage", "indexedDB"];
/** The first word of §7.3 a view's source names, or a non-relative dynamic `import(`; null when clean. */
export declare function lintSkinViewSource(source: string): string | null;
/** The custom view the resolution chose: its entry, its declared version and its URL on the mount. */
export interface SkinViewEntry {
    readonly entry: string;
    readonly api: string;
    readonly url: string;
}
/** The sandboxed iframe tier's entry the resolution chose (§6.7): its URL on the mount. */
export interface SkinModguiEntry {
    readonly entry: string;
    readonly url: string;
}
/**
 * Whether an opted-in `modgui` entry passes the licence gate (§6.7): the ONE check the server's
 * resolver and any other caller apply, never re-derived. `licence` is `override.licence` as read
 * off disk now (the importer's own check happened once, at import; this one happens on every read).
 */
export declare function isSkinLicenceAllowed(licence: string): boolean;
/**
 * The resolution of one plugin id (§6.5): which level answered (or none), the parsed override, the
 * view entry and its declared version, the package ETag, and every refusal, which the panel header
 * marks. One value every client reads.
 */
export interface SkinResolution {
    readonly plugin: string;
    readonly level: SkinLevel | null;
    /** The package's base URL on the mount, with a trailing slash; null when no level answered. */
    readonly base: string | null;
    readonly etag: string | null;
    readonly override: SkinOverride | null;
    /** The view to import, or null: none declared, or refused (its refusal is in `refusals`). */
    readonly view: SkinViewEntry | null;
    /** The sandboxed iframe tier's entry, or null: not opted in, or refused (§6.7, in `refusals`). */
    readonly modgui?: SkinModguiEntry | null;
    readonly refusals: readonly Refusal[];
}
/**
 * The base URL of a package on the mount: the directory name, itself URL-encoded once more, so a
 * `%` the directory name holds survives the one decode a server applies to a path.
 */
export declare function skinBaseUrl(pluginId: string): string;
export type SkinLicence = (typeof SKIN_LICENCE_ALLOW_LIST)[number];
export declare const MODGUI_NS = "http://moddevices.com/ns/modgui#";
export declare const LV2_NS = "http://lv2plug.in/ns/lv2core#";
export declare const DOAP_NS = "http://usefulinc.com/ns/doap#";
/**
 * The `modgui:` properties the importer knows on a `modgui:gui` node: mod-ui's whole list, not only
 * the ones a reviewed bundle used (docs/skin-package.md); any other is refused.
 */
export declare const MODGUI_GUI_PROPERTIES: readonly ["resourcesDirectory", "iconTemplate", "settingsTemplate", "javascript", "stylesheet", "screenshot", "thumbnail", "documentation", "discussionURL", "brand", "label", "model", "panel", "color", "knob", "port", "monitoredOutputs"];
/**
 * The `modgui:gui` properties whose value is a file of the bundle: each must resolve inside it and is
 * copied with the package. `documentation` is one only when it names a `file:` IRI; a web address
 * there, and `discussionURL` always, are kept as text and never fetched.
 */
export declare const MODGUI_FILE_PROPERTIES: readonly ["iconTemplate", "settingsTemplate", "javascript", "stylesheet", "screenshot", "thumbnail", "documentation"];
/**
 * The modgui files whose image references (`src="..."`, `url(...)`) must resolve inside the bundle. Not
 * the stylesheet: MOD's shared pedal themes name files no one bundle carries, on purpose.
 */
export declare const MODGUI_TEMPLATE_PROPERTIES: readonly ["iconTemplate", "settingsTemplate"];
/** mod-ui's server route a template names the bundle's resources directory by: `/resources/<f>`. */
export declare const MODGUI_RESOURCES_ROUTE = "/resources/";
/**
 * mod-ui's own routes, the directories of its html directory its static handler serves (`/fonts/<name>/...`,
 * `/img/icons/...`, `/js/...`, `/css/...`, `/include/...`): the other absolute paths a template may name, a
 * file the drawing supplies or replaces, kept as text and never fetched. Any other absolute path is outside
 * the bundle.
 */
export declare const MODGUI_SERVER_ROUTES: readonly ["/fonts/", "/img/", "/js/", "/css/", "/include/"];
/** The `lv2:` properties the importer knows on a `modgui:port` node; any other is refused. */
export declare const MODGUI_PORT_PROPERTIES: readonly ["index", "symbol", "name"];
/** The importer's refusals (§6.6), each naming the file it read; nothing is written on any of them. */
export declare const MODGUI_IMPORT_REFUSALS: readonly ["MODGUI_NOT_FOUND", "MODGUI_TTL_INVALID", "MODGUI_NO_LICENCE", "MODGUI_LICENCE_UNMAPPED", "MODGUI_LICENCE_REFUSED", "MODGUI_UNKNOWN_PROPERTY", "MODGUI_PORT_UNKNOWN", "MODGUI_IMAGE_NOT_FOUND", "MODGUI_PATH_ESCAPE", "MODGUI_TARGET_EXISTS"];
export type ModguiImportRefusal = (typeof MODGUI_IMPORT_REFUSALS)[number];
/**
 * The SPDX expression a `doap:license` value names, or `null` when it names none this map reads
 * (§6.6): an `spdx.org/licenses/<id>` IRI or a bare SPDX literal as that id, an
 * `opensource.org/licenses/<id>` IRI as the SPDX id it names, DOAP's unversioned gpl/lgpl as
 * GPL-2.0-or-later/LGPL-2.1-or-later. Mapping is not permission: {@link isSkinLicenceAllowed} decides.
 */
export declare function spdxFromDoapLicence(value: {
    readonly iri?: string;
    readonly literal?: string;
}): string | null;
