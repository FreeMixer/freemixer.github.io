export function parseFont(bytes: any): {
    unitsPerEm: number;
    ascent: number;
    descent: number;
    /** `{ advance, polys }` of a character; a character the font lacks is its .notdef. */
    glyph(ch: any): any;
};
