/**
 * @typedef {{ symbol: string, name: string, index: number, control: boolean, input: boolean,
 *   designation?: string, unit?: string, unitLabel?: string, group?: string, notOnGui?: boolean }} Port
 * @typedef {{ symbol?: string, name?: string, displayPriority?: number }} OwnGroup
 * @typedef {{ uri: string, ports: Port[], groups?: Record<string, OwnGroup> }} PluginPorts
 * @typedef {{ ports: { symbol: string, index: number, name?: string }[] }} ModguiLayout
 * @typedef {{ symbol: string, name: string, displayPriority: number, ports: string[], rule: number, node?: string }} Group
 */
/** The controls a screen shows: control inputs, not host-driven, not marked notOnGUI. In lv2:index order. */
export function placeableControls(ports: any): any;
/**
 * Infer `plugin`'s port groups. `modgui` is the plugin's own MOD GUI layout, or null when it has none.
 * @param {PluginPorts} plugin
 * @param {ModguiLayout | null} [modgui]
 * @param {{ rules?: typeof RULES, prefixPasses?: typeof PREFIX_PASSES }} [options] another rule order, or another
 *   order of rule 3's passes (the orders are the contract: tests only)
 */
export function inferGroups(plugin: PluginPorts, modgui?: ModguiLayout | null, options?: {
    rules?: typeof RULES;
    prefixPasses?: typeof PREFIX_PASSES;
}): {
    outcome: string;
    reason: any;
    detail: any;
    attempt: {
        groups: any;
        unplaced: any;
        placedBy: {
            [k: string]: number;
        };
    };
} | {
    outcome: string;
    reason: string;
    groups?: undefined;
    placedBy?: undefined;
} | {
    outcome: string;
    groups: any;
    placedBy: {
        [k: string]: number;
    };
    reason?: undefined;
};
/** A valid lv2:symbol ([_a-zA-Z][_a-zA-Z0-9]*) from any text. */
export function lv2Symbol(text: any): string;
/** A name's words: bracketed text dropped, split at punctuation, spaces and letter-digit boundaries. */
export function nameTokens(name: any): string[];
/** A symbol's words: split at `_`, `-`, a lower-to-upper case change and letter-digit boundaries. */
export function symbolTokens(symbol: any): string[];
/**
 * The plugins the triples describe, by URI: every subject typed lv2:Plugin, or carrying an indexed lv2:port (a plugin's own
 * file read without its bundle's manifest, which is where some bundles, LSP's, state the type).
 */
export function pluginUris(triples: any): any[];
/**
 * The ports of plugin `uri` as the rules read them, and the plugin's own group nodes.
 * @returns {PluginPorts}
 */
export function readPluginPorts(triples: any, uri: any): PluginPorts;
/**
 * The plugin's own MOD GUI layout: the ports its `modgui:gui` names, in their order; null when the plugin has no
 * MOD GUI (the test omx-modgui-sync makes: a `modgui:gui` on the plugin's URI).
 * @returns {ModguiLayout | null}
 */
export function readModguiLayout(triples: any, uri: any): ModguiLayout | null;
/**
 * Controls one screen of the Zynthian touchscreen shows. A plugin with this many placeable controls or fewer
 * already fits one screen, so groups would not change what the operator sees: nothing to do.
 */
export const SCREEN_SIZE: 4;
/**
 * The smallest group the rules may make. A group of one is a screen with one control: worse than port order,
 * which at least fills the screen. Every rule consults it before it makes a group, so no generated group is ever
 * under it and the confidence check does not test it again. The plugin's OWN groups (rule 1) are kept whatever their
 * size: what the plugin states is kept.
 */
export const MIN_GROUP_SIZE: 2;
/**
 * Controls a confident grouping may leave unplaced. Zero: an unplaced control falls into the consumer's catch-all
 * ("Params" on the touchscreen) beside our groups, which is a layout nobody inferred. Every control is placed, or
 * the plugin is left alone.
 */
export const MAX_UNPLACED: 0;
/**
 * At least two groups. One group holding every control is what the plugin shows today with a title on top.
 */
export const MIN_GROUPS: 2;
/**
 * At most this many groups: the ceiling we accept, not a size any plugin needs. A group is at least one screen, and
 * 32 screens of sections is already more than an operator pages through. A 32-band equaliser does not fit under it
 * once its own input and output groups are counted (LSP's x32 graphic equalisers need 36) and is refused, left in
 * port order; so is anything wider, where the rules are more likely slicing a step sequencer or a matrix than finding
 * sections. Raising it is a ruling on how many screens are too many, not a fix.
 */
export const MAX_GROUPS: 32;
/**
 * The share of controls rule 5 (a contiguous run of lv2:index) may place. Index runs carry no meaning of their
 * own: they only fill the gaps between groups the plugin's words (rules 1-4, 6) found. When the gaps are most of
 * the plugin, the "grouping" is port order cut at arbitrary points: not confident.
 */
export const MAX_INDEX_RUN_SHARE: 0.5;
/**
 * Designations the host drives, never shown as a control on a screen: they need no group and do not count as
 * placeable. lv2:enabled is the touchscreen's bypass (zynthian_lv2.py reads it as such).
 */
export const HOST_DESIGNATIONS: Set<string>;
/** Rule 3: a word that names a numbered section; "Section 1" names the group of every control numbered 1. */
export const SECTION_WORDS: Set<string>;
export const RULES: {
    n: number;
    name: string;
    run: typeof ruleOwnGroups;
}[];
/**
 * Rule 3's passes, in order. The symbol's trailing number comes first: a symbol numbers a band the same way on every
 * control (`xs_9`, `g_9`), where a name may print its frequency ("Band gain 1K", "31.5") and number nothing.
 */
export const PREFIX_PASSES: string[][];
export type Port = {
    symbol: string;
    name: string;
    index: number;
    control: boolean;
    input: boolean;
    designation?: string;
    unit?: string;
    unitLabel?: string;
    group?: string;
    notOnGui?: boolean;
};
export type OwnGroup = {
    symbol?: string;
    name?: string;
    displayPriority?: number;
};
export type PluginPorts = {
    uri: string;
    ports: Port[];
    groups?: Record<string, OwnGroup>;
};
export type ModguiLayout = {
    ports: {
        symbol: string;
        index: number;
        name?: string;
    }[];
};
export type Group = {
    symbol: string;
    name: string;
    displayPriority: number;
    ports: string[];
    rule: number;
    node?: string;
};
/** 1: the plugin's own pg:group assignments. The plugin's node, symbol, name and priority are kept. */
declare function ruleOwnGroups(state: any, rule: any): void;
export {};
