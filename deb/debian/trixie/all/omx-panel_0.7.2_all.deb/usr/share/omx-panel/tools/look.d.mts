/** Every rule of `css`, in order: its selectors and its declarations. Comments are dropped. */
export function parseRules(css: any): {
    selectors: any;
    decls: any[][];
}[];
/** A selector's specificity at `axes` (one for :root, one more per attribute), or -1 when the root
 * element does not match it. Only `:root` and `[data-<axis>="<value>"]` are selectors here. */
export function specificity(selector: any, axes: any): number;
/** Every custom property of `css` at `axes`, cascaded and its var()s followed. */
export function resolveTokens(css: any, axes?: Readonly<{
    theme: "dark";
    accent: "cyan";
    finish: "aluminium";
    style: "modern";
}>): {};
/** tools/look.json's text: the look, and each token a renderer reads as plain values. */
export function emitLook(css: any, axes?: Readonly<{
    theme: "dark";
    accent: "cyan";
    finish: "aluminium";
    style: "modern";
}>): string;
export const TOKENS_CSS: string;
export const LOOK_JSON: string;
/** The look the plugins wear: the console's openmixer board, its axes as the root element carries them. */
export const LOOK: Readonly<{
    theme: "dark";
    accent: "cyan";
    finish: "aluminium";
    style: "modern";
}>;
/** The tokens a renderer reads, in the order tools/look.json lists them. */
export const LOOK_TOKENS: readonly string[];
/** The tokens that are not colours: the CSS font stack, and the font file (relative to tools/) the raster reads. */
export const NOT_COLOURS: readonly string[];
