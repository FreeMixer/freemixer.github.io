/** `#rrggbb` -> [r, g, b]. A token that is not a plain hex colour is refused, never guessed. */
export function rgbOf(hex: any): number[];
export function canvas(w: any, h: any): {
    w: any;
    h: any;
    data: Uint8Array<ArrayBuffer>;
};
/** A rectangle with rounded corners of radius `r`. */
export function roundRect(c: any, x: any, y: any, w: any, h: any, r: any, rgb: any): void;
/** A filled disc. */
export function disc(c: any, cx: any, cy: any, r: any, rgb: any): void;
/** A segment of half-width `hw` with round caps. */
export function segment(c: any, ax: any, ay: any, bx: any, by: any, hw: any, rgb: any): void;
/** The width in px of `text` set in `font` at `px` (advances only: no kerning, no hinting). */
export function textWidth(font: any, text: any, px: any): number;
/** `text` cut to fit `maxW` px, with ".." for what was dropped; whole when it fits. */
export function fitText(font: any, text: any, px: any, maxW: any): any;
/**
 * `text` in `font` at `px`, its baseline at `y` and its left edge (`align` 'left'), centre ('centre') or right
 * ('right') at `x`. Each glyph is the font's outline scaled to px, its points snapped to 1/16 px, filled by
 * the non-zero rule with the same SS×SS sampling as the shapes, so the coverage is the shape's own.
 */
export function drawText(c: any, font: any, text: any, x: any, y: any, px: any, rgb: any, align?: string): void;
/** One fixed-Huffman deflate block over `raw`, matching only at the `distances` given, greedily. */
export function deflateFixed(raw: any, distances: any): Uint8Array<ArrayBuffer>;
/** The scanlines PNG compresses: filter byte 0 (None) then the row's RGBA. */
export function scanlines(c: any): Uint8Array<ArrayBuffer>;
/** A PNG (8-bit RGBA) of the canvas. `period` is a horizontal repeat in pixels worth matching (a
 * film strip's frame width); the matcher also tries the previous pixel and the previous row. */
export function encodePng(c: any, period?: number): Buffer<ArrayBuffer>;
export function snap(v: any): number;
