/** Go to slot `to`: the running values are stored in the slot left, and an empty slot takes a copy, so nothing moves. */
export function switchTo(doc: any, values: any, to: any): {
    moves: {
        symbol: string;
        value: any;
    }[];
    unknown: string[];
    doc: any;
};
/** Put the running values in another slot. Nothing moves. */
export function copyTo(doc: any, values: any, to: any): {
    doc: any;
    moves: never[];
    unknown: never[];
};
/** Keep `values` as the step to come back to. The same values twice are one step; a new step ends what could be redone. */
export function capture(ring: any, values: any): any;
export const COMPARE_FORMAT: "org.openmixer.compare/1";
export const COMPARE_SLOTS: readonly string[];
/** How many steps an undo ring keeps. */
export const RING_BOUND: 64;
export class CompareRefused extends Error {
    constructor(code: any, message: any);
    code: any;
}
export function emptyCompare(): {
    format: string;
    active: string | undefined;
    slots: {};
};
export function filledSlots(doc: any): string[];
export function emptyRing(): {
    undo: never[];
    redo: never[];
};
export function undo(ring: any, values: any): {
    ring: any;
    moves: never[];
    unknown: never[];
} | {
    moves: {
        symbol: string;
        value: any;
    }[];
    unknown: string[];
    ring: {
        [x: number]: any[];
    };
};
export function redo(ring: any, values: any): {
    ring: any;
    moves: never[];
    unknown: never[];
} | {
    moves: {
        symbol: string;
        value: any;
    }[];
    unknown: string[];
    ring: {
        [x: number]: any[];
    };
};
