/**
 * The standard widget control `c` (a descriptor control) is drawn with: `{ widget }`, a meter's with
 * its `measurement` (null when the descriptor does not state it), a trigger's switch `momentary`. A
 * declared widget wins; else a read-only travel in a level unit is a meter and any other read-only
 * control a display, a toggle or a trigger a switch, a choice a selector, a travel a knob.
 */
export function widgetOf(c: any, declared: any): {
    widget: any;
    measurement?: undefined;
    momentary?: undefined;
} | {
    widget: string;
    measurement: any;
    momentary?: undefined;
} | {
    widget: string;
    momentary: boolean;
    measurement?: undefined;
};
/**
 * The family of a plugin whose controls are `controls` (descriptor controls): `{ family }`, and for a
 * declared family none of its controls' meanings backs, `{ family, needs }` naming what it lacks. With
 * no declared family, an effect takes the first family whose meanings it carries; an instrument, or a
 * plugin no family fits, is none.
 */
export function familyOf(controls: any, declared: any, features?: any[]): {
    family: any;
    needs: any;
} | {
    family: any;
    needs?: undefined;
};
/**
 * The panel of `descriptor`, of any origin. `panel` (a declaration's) gives the family, sections,
 * order, roles, widgets and graphs; with none, the sections are the controls' groups, the family the
 * one their meanings make and the roles the ones their meanings play. `ns` is the label-key namespace
 * (without one the label keys are null); `choiceUnits` and `byKind` are a declaration's extras.
 */
export function panelLayout(descriptor: any, { panel, ns, where, choiceUnits, byKind }?: {
    where?: string | undefined;
    choiceUnits?: {} | undefined;
    byKind?: {} | undefined;
}): {
    origin: any;
    family: any;
    sections: any;
    controls: any;
    roles: any[];
    unpublished: {
        role: string | undefined;
        symbol: any;
        why: string;
    }[];
    displays: any;
    defaults: any;
    ports: {
        inputs: {
            id: any;
            name: any;
            role: any;
            channels: any;
        }[];
        outputs: {
            id: any;
            name: any;
            role: any;
            channels: any;
        }[];
        sidechain: boolean;
        notes: boolean;
    };
    easy: any[];
};
/** The pages of clap.remote-controls/2 by the page rule: each section's controls in order, cut into
 * pages of `perPage` (default eight, the surface's slots), a section of several pages numbering them; a
 * short page's slots are null. With `perPage` stated, a group that fits a page is not split across two
 * (a page ends early to keep it whole; a group wider than a page is cut), and a section of several
 * pages names each page by the controls it holds, "Band: Freq - Q". Left out, the cut is the plain one.
 * With `easyFirst` the Easy controls come first, on pages of their own named Easy, Easy 2, and do not repeat. */
export function pagesOf(x: any, { perPage, easyFirst }?: {
    easyFirst?: boolean | undefined;
}): any[];
/** The canonical serialisation: UTF-8, LF after every line, TAB-separated, parameters by symbol, the
 * fallback labels left out. */
export function panelCanonical(x: any): string;
export const PANEL_ID: "org.openmixer.panel-description/1";
/** The extension's families, by enum value. */
export const FAMILIES: string[];
/** The widgets a face serves, by enum value. */
export const WIDGETS: string[];
/** The standard widgets a panel picks from a descriptor; a representation (a skin) draws each. */
export const STANDARD_WIDGETS: string[];
/** What a meter measures. */
export const MEASUREMENTS: string[];
export function servedWidget(standard: any): any;
/** The display kinds and sources, by enum value. */
export const DISPLAY_KINDS: string[];
export const DISPLAY_SOURCES: string[];
export const PLACEMENTS: string[];
export function unitToken(unit: any): any;
export namespace ROLES {
    let none: {};
    namespace gate {
        export { LVL as threshold };
        export { DB as range };
        export { T as attack };
        export { T as release };
        export { T as hold };
        export { DB as knee_start };
        export { DB as knee_end };
        export { DB as hysteresis };
        export { RATIO as ratio };
        export { CHOICE as key_listen };
    }
    namespace dynamics {
        export let mix: string[];
        export { DB as output };
        export { LVL as threshold };
        export { RATIO as ratio };
        export { T as attack };
        export { T as release };
        export { DB as knee };
        export { DB as makeup };
        export let lookahead: string[];
    }
    namespace limiter {
        export { LVL as ceiling };
        export { T as release };
        let lookahead_1: string[];
        export { lookahead_1 as lookahead };
        export { LVL as threshold };
    }
    namespace deesser {
        export { FREQ as frequency };
        export { LVL as threshold };
        export { DB as range };
        export let width: string[];
        export { RATIO as ratio };
        export { T as attack };
        export { T as release };
        export { DB as knee };
        export { CHOICE as mode };
        export { CHOICE as listen };
    }
    namespace eq {
        export { CHOICE as band_type };
        export { FREQ as band_freq };
        export let band_gain: string[];
        export let band_q: string[];
        export { CHOICE as band_on };
        export { FREQ as hpf_freq };
        export let hpf_slope: string[];
        export { CHOICE as hpf_on };
        export { FREQ as lpf_freq };
        export let lpf_slope: string[];
        export { CHOICE as lpf_on };
        export { DB as output };
    }
    namespace filter {
        export { FREQ as cutoff };
        export { PLAIN as resonance };
        export { CHOICE as filter_type };
    }
    namespace drive {
        export { DB as drive };
        export { PLAIN as tone };
        export { CHOICE as model };
    }
    namespace modulation {
        export let rate: string[];
        export let depth: string[];
        export { PLAIN as feedback };
        export { CHOICE as voices };
        export { PLAIN as spread };
        export { CHOICE as shape };
    }
    namespace delay {
        export { T as time };
        export { PLAIN as feedback };
        export { PLAIN as tone };
        export { CHOICE as sync };
        export { CHOICE as division };
        export { CHOICE as pingpong };
    }
    namespace reverb {
        export { PLAIN as size };
        export { T as decay };
        export { CHOICE as algorithm };
        export let predelay: string[];
        export { PLAIN as damping };
        export { PLAIN as width };
        export { FREQ as low_cut };
        export { FREQ as high_cut };
    }
    namespace pitch {
        let shift: string[];
        let fine: string[];
    }
}
/** The roles that repeat by index, one control per band: schema/panel.schema.json's `$defs.indexedRole`. */
export const INDEXED_ROLES: any;
export namespace FAMILY_MEANINGS {
    export namespace limiter_1 {
        let backs: string[];
        let infer: string[][];
    }
    export { limiter_1 as limiter };
    export namespace deesser_1 {
        let backs_1: string[];
        export { backs_1 as backs };
        let infer_1: string[][];
        export { infer_1 as infer };
    }
    export { deesser_1 as deesser };
    export namespace gate_1 {
        let backs_2: string[];
        export { backs_2 as backs };
        let infer_2: string[][];
        export { infer_2 as infer };
    }
    export { gate_1 as gate };
    export namespace dynamics_1 {
        let backs_3: string[];
        export { backs_3 as backs };
        let infer_3: string[][];
        export { infer_3 as infer };
    }
    export { dynamics_1 as dynamics };
    export namespace eq_1 {
        let backs_4: string[];
        export { backs_4 as backs };
        let infer_4: string[][];
        export { infer_4 as infer };
    }
    export { eq_1 as eq };
    export namespace filter_1 {
        let backs_5: string[];
        export { backs_5 as backs };
        let infer_5: string[][];
        export { infer_5 as infer };
    }
    export { filter_1 as filter };
    export namespace drive_1 {
        let backs_6: string[];
        export { backs_6 as backs };
        let infer_6: string[][];
        export { infer_6 as infer };
    }
    export { drive_1 as drive };
    export namespace delay_1 {
        let backs_7: string[];
        export { backs_7 as backs };
        let infer_7: string[][];
        export { infer_7 as infer };
    }
    export { delay_1 as delay };
    export namespace reverb_1 {
        let backs_8: string[];
        export { backs_8 as backs };
        let infer_8: string[][];
        export { infer_8 as infer };
    }
    export { reverb_1 as reverb };
    export namespace pitch_1 {
        let backs_9: string[];
        export { backs_9 as backs };
        let infer_9: string[][];
        export { infer_9 as infer };
    }
    export { pitch_1 as pitch };
    export namespace modulation_1 {
        let backs_10: null;
        export { backs_10 as backs };
        let infer_10: string[][];
        export { infer_10 as infer };
    }
    export { modulation_1 as modulation };
}
export function snake(s: any): any;
/** A descriptor with no control to lay out (none stated, or every one hidden): there is no panel to make, and the
 * layout says so by code instead of answering an empty one. */
export class NoControls extends Error {
    code: string;
}
export function keyOf(c: any): any;
/** The key a control carries its declared group under, for the page cut: a symbol, so no serialisation sees it. */
export const GROUP: unique symbol;
/** The name of the Easy controls' page and of a MOD GUI's first section. */
export const EASY_PAGE: "Easy";
/** The surface's slots per page, CLAP_REMOTE_CONTROLS_COUNT. */
export const PAGE_SIZE: 8;
export function panelFingerprint(x: any): string;
declare const LVL: string[];
declare const DB: string[];
declare const T: string[];
declare const RATIO: string[];
declare const CHOICE: string[];
declare const FREQ: string[];
declare const PLAIN: string[];
export {};
