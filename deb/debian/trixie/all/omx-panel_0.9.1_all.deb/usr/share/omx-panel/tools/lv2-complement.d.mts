/** The writer's identity in a marker: a hash of the modules that decide what is written. A changed rule rewrites. */
export function writerId(): string;
/**
 * @typedef {{ name: string, path: string, url: string, bytes: Buffer, triples: { s: any, p: any, o: any }[] }} TtlFile
 * @typedef {{ dir: string, url: string, files: Map<string, TtlFile>, plugins: string[], seeAlso: Map<string, string[]>,
 *   hash: string, dynamic: boolean }} InstalledBundle
 */
/**
 * Read the installed bundle at `dir`. Throws a Refusal for TTL the reader cannot parse or a plugin data file outside
 * the bundle; returns null for a directory with no manifest.ttl.
 * @returns {InstalledBundle | null}
 */
export function readInstalledBundle(dir: any): InstalledBundle | null;
/** The triples lilv holds for `uri`: the manifest and its seeAlso files, each file's blank nodes local to it. */
export function pluginTriples(bundle: any, uri: any): {
    s: any;
    p: any;
    o: any;
}[];
/**
 * @typedef {{ uri: string, verdict: any, version?: any }} PlannedPlugin
 * @typedef {{ bundle: InstalledBundle, plugins: PlannedPlugin[], write: boolean, refusal?: Refusal }} Plan
 */
/**
 * What to do with an installed bundle. `elsewhere(uri)` lists the other installed bundles declaring `uri` (a plugin
 * in two bundles is one lilv picks between by version; the restatement cannot say which it replaces).
 * @param {InstalledBundle} bundle
 * @param {{ elsewhere?: (uri: string) => string[] }} [options]
 * @returns {Plan}
 */
export function planBundle(bundle: InstalledBundle, options?: {
    elsewhere?: (uri: string) => string[];
}): Plan;
/**
 * The bundle's files: every installed TTL file lilv reads for the bundle's plugins, restated, with the versions
 * raised, the seeAlso references pointing at the restated files, and the inferred groups added. `target`, the
 * directory the bundle will be written to, lets the group-node guard also resolve each generated node where lilv will.
 * @param {Plan} plan
 * @param {string} [target]
 * @returns {Map<string, string>} file name in the new bundle -> its text
 */
export function renderBundle(plan: Plan, target?: string): Map<string, string>;
/** The marker's text: the installed bundle, the writer, the content hash, then one line per plugin. */
export function markerText(plan: any, writer?: string): string;
/** A written bundle is up to date when its marker names the same installed bundle, writer and content hash. */
export function isFresh(outBundle: any, plan: any, writer?: string): boolean;
/**
 * The name of the bundle written for an installed one: `omx-complement-<stem>.lv2`. When `repeated` (another installed
 * bundle would take the same name: one basename in two roots, or names that differ only in what the stem replaces),
 * a short hash of the bundle's own path joins the stem, `omx-complement-<stem>-<hash>.lv2`: stable for that path, and
 * different for every path.
 */
export function outName(bundleDir: any, repeated?: boolean): string;
/**
 * Write `plan`'s bundle at `target`: built in a work directory under `stateDir` and moved in whole, so lilv never
 * reads half a bundle. Every other entry of the installed bundle is linked in, so a plugin that reads its own files
 * from the bundle path lilv hands it (ours now) still finds them.
 */
export function writeBundle(plan: any, target: any, stateDir: any, writer?: string): void;
/** Every bundle directory on the search list, in its order, one reached twice by its first path; the writer's own bundles (marked) are not installed ones. */
export function installedBundles(lv2Path: any): string[];
/**
 * Plan (and, unless `dryRun` or `check`, write) a complement for every installed bundle on `lv2Path` that needs one,
 * into `outDir`, and remove every bundle of ours that is no longer wanted. Ours is a directory `omx-complement-*.lv2`
 * holding the marker; nothing else in `outDir` is ever removed or written. A bundle of ours is kept only when this run
 * finds it up to date or writes it again; any other is stale and removed, the log naming it and why: its installed
 * bundle is gone (or no longer on the search list), changed and is now refused, needs no groups now, or is refused on
 * the current rules. `check` writes and removes nothing and names each bundle of ours that is stale or out of date.
 * @returns {{ counts: Record<string, number>, refusals: Record<string, number> }}
 */
export function sync({ lv2Path, outDir, stateDir, dryRun, check, verbose, only, log, writer }: {
    lv2Path: any;
    outDir: any;
    stateDir: any;
    dryRun?: boolean | undefined;
    check?: boolean | undefined;
    verbose?: boolean | undefined;
    only?: never[] | undefined;
    log?: (() => void) | undefined;
    writer?: string | undefined;
}): {
    counts: Record<string, number>;
    refusals: Record<string, number>;
};
/** A directory of ours: a real directory (not a link) holding the marker. The marker is the proof of ownership. */
export function isOurs(dir: any): boolean;
/** The summary line. */
export function summary({ counts, refusals }: {
    counts: any;
    refusals: any;
}, dryRun?: boolean): string;
/** The marker in every bundle this writer makes, named after the command that runs it (omx-modgui-sync's model). */
export const MARKER: ".omx-complement-sync";
/** Every bundle this writer makes is omx-complement-<installed bundle's name>.lv2. */
export const PREFIX: "omx-complement-";
/** lilv reads lv2:minorVersion and lv2:microVersion with atoi into an int: a bump past this overflows. */
export const VERSION_CEILING: 2147483647;
/** A bundle the restatement cannot carry: `reason` is the code, `detail` names the file or the plugin. */
export class Refusal extends Error {
    constructor(reason: any, detail: any);
    reason: any;
    detail: any;
}
export type TtlFile = {
    name: string;
    path: string;
    url: string;
    bytes: Buffer;
    triples: {
        s: any;
        p: any;
        o: any;
    }[];
};
export type InstalledBundle = {
    dir: string;
    url: string;
    files: Map<string, TtlFile>;
    plugins: string[];
    seeAlso: Map<string, string[]>;
    hash: string;
    dynamic: boolean;
};
export type PlannedPlugin = {
    uri: string;
    verdict: any;
    version?: any;
};
export type Plan = {
    bundle: InstalledBundle;
    plugins: PlannedPlugin[];
    write: boolean;
    refusal?: Refusal;
};
