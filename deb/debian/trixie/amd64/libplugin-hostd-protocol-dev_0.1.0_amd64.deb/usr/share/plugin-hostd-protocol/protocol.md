# The protocol

The commands, replies and error codes of plugin-hostd-protocol 0.1. They are mod-host's, and this page is the
"Commands (or Protocol)" section of mod-host's README (FreeMixer/mod-host, branch freemixer, 013ac7d), kept as it is.
Copyright 2013-2026 Filipe Coelho, MOD Audio UG and the mod-host contributors, GPL-3.0-or-later.

Where it says "mod-host", read "the host": any host built on this library answers these commands. The library parses
and dispatches them; what a command does to a plugin is the host's backend (`host_backend_t`, `include/host-backend.h`).

Commands (or Protocol)
----------------------

The commands supported by mod-host are:

    add <lv2_uri> <instance_number> [client_name]
        * add an LV2 plugin encapsulated as a jack client
        e.g.: add "http://lv2plug.in/plugins/eg-amp" 0
        instance_number must be any value between 0 ~ 9990, inclusively
        client_name is optional; when omitted the jack client (and so the graph node) is
        named "effect_<instance_number>", same as always. When given, mod-host tries to
        open the jack client under that name instead -- so a host running many plugins
        shows a graph with a name per plugin instead of an undifferentiated effect_0,
        effect_1, effect_2... The name is sanitised for jack (':' is replaced with '_',
        since jack uses ':' as the client:port separator, and it is truncated to the
        running jack backend's client name limit) and, on a collision with an existing
        jack client, disambiguated by appending "_<instance_number>". If the sanitised
        name is empty, or the name still collides after the instance number is appended,
        mod-host falls back to the default "effect_<instance_number>" rather than fail
        the add.
        e.g.: add "http://lv2plug.in/plugins/eg-amp" 0 "channel1-eg-amp"

    remove <instance_number>
        * remove an LV2 plugin instance (and also the jack client)
        e.g.: remove 0
        when instance_number is -1 all plugins will be removed

    preset_load <instance_number> <preset_uri>
        * load a preset state of an effect instance
        e.g.: preset_load 0 "http://drobilla.net/plugins/mda/presets#JX10-moogcury-lite"

    preset_save <instance_number> <preset_name> <dir> <file_name>
        * save a preset state of an effect instance
        e.g.: preset_save 0 "My Preset" "/home/user/.lv2/my-presets.lv2" "mypreset.ttl"

    preset_show <preset_uri>
        * show the preset information of requested URI
        e.g.: preset_show "http://drobilla.net/plugins/mda/presets#EPiano-bright"

    connect <origin_port> <destination_port>
        * connect two jack ports
        e.g.: connect "system:capture_1" "effect_0:in"

    disconnect <origin_port> <destination_port>
        * disconnect two jack ports
        e.g.: disconnect "system:capture_1" "effect_0:in"

    bypass <instance_number> <bypass_value>
        * toggle effect processing
        e.g.: bypass 0 1
        if bypass_value = 1 bypass effect
        if bypass_value = 0 process effect

    param_set <instance_number> <param_symbol> <param_value>
        * set the value of a control port
        e.g.: param_set 0 "gain" 2.5

    param_get <instance_number> <param_symbol>
        * get the value of a control port
        e.g.: param_get 0 "gain"

    param_monitor <instance_number> <param_symbol> <cond_op> <value>
        * monitor a control port according to a condition
        e.g: param_monitor 0 "gain" ">" 2.5

    patch_set <instance_number> <property_uri> <value>
        * set the value of a control port
        e.g.: patch_set 0 "gain" 2.5

    patch_get <instance_number> <property_uri>
        * get the value of a control port
        e.g.: patch_get 0 "gain"

    licensee <instance_number>
        * get the licensee name for a commercial plugin
        e.g.: licensee 0

    monitor <addr> <port> <status>
        * open a socket port for monitoring parameter changes
        e.g: monitor localhost 12345 1
        if status = 1 start monitoring
        if status = 0 stop monitoring

    monitor_output <instance_number> <param_symbol>
        * request monitoring of an output control port (on the feedback port)
        e.g.: monitor_output 0 "meter"

    midi_learn <instance_number> <param_symbol> <minimum> <maximum>
        * start MIDI learn for a control port
        e.g.: midi_learn 0 "gain" 0.0 1.0

    midi_map <instance_number> <param_symbol> <midi_channel> <midi_cc> <minimum> <maximum>
        * map a MIDI controller to a control port
        e.g.: midi_map 0 "gain" 0 7 0.0 1.0
        a non-standard midi_cc value of 131 (0x83) is used for pitchbend

    midi_unmap <instance_number> <param_symbol>
        * unmap the MIDI controller from a control port
        e.g.: midi_unmap 0 "gain"

    monitor_midi_program <midi_channel> <enable>
        * listen to MIDI program change messages (on the feedback port)
        e.g.: monitor_midi_program 0 1

    set_midi_program_change_pedalboard_bank_channel <enable> <midi_channel>
        * set the MIDI channel which changes pedalboard banks on MIDI program change. <midi_channel> is in the range of [0,15].
        e.g.: set_midi_program_change_pedalboard_bank_channel 1 5 to enable listening for bank changes on channel 6

    set_midi_program_change_pedalboard_snapshot_channel <enable> <midi_channel>
        * set the MIDI channel which changes pedalboard snapshots on MIDI program change. <midi_channel> is in the range of [0,15].
        e.g.: set_midi_program_change_pedalboard_snapshot_channel 1 4 to enable listening for preset changes on channel 5

    cc_map <instance_number> <param_symbol> <device_id> <actuator_id> <label> <value> <minimum> <maximum> <steps> <extraflags> <unit> <scalepoints_count> <scalepoints...>
        * map a Control Chain actuator to a control port
        e.g.: cc_map 0 "gain" 0 1 "Gain" 0.0 -24.0 3.0 33 0 "dB" 0

    cc_unmap <instance_number> <param_symbol>
        * unmap the Control Chain actuator from a control port
        e.g.: cc_unmap 0 "gain"

    cc_value_set <instance_number> <param_symbol> <value>
        * set the value of a  mapped Control Chain actuator
        e.g.: cc_value_set 0 "gain" 2.5

    cv_map <instance_number> <param_symbol> <source_port_name> <minimum> <maximum> <operational-mode>
        * map a CV source port to a control port, operational-mode being one of '-', '+', 'b' or '='
        e.g.: cv_map 0 "gain" "AMS CV Source:CV Out 1" -24.0 3.0 =

    cv_unmap <instance_number> <param_symbol>
        * unmap the CV source port actuator from a control port
        e.g.: cv_unmap 0 "gain"

    cpu_load
        * return current jack cpu load

    load <file_name>
        * load a history command file
        * dummy way to save/load workspace state
        e.g.: load my_setup

    save <file_name>
        * saves the history of typed commands
        * dummy way to save/load workspace state
        e.g.: save my_setup

    bundle_add <bundle_path>
        * add a bundle to the running lv2 world
        e.g.: bundle_add "/path/to/bundle.lv2"

    bundle_remove <bundle_path> <resource>
        * remove a bundle from the running lv2 world
        e.g.: bundle_remove "/path/to/bundle.lv2" ""

    feature_enable <feature> <enable>
        * enable or disable a feature
        * feature can be one of "aggregated-midi", "freewheeling" or "processing"
        * the "aggregated-midi" feature requires the use of jack2 and mod-midi-merger to be installed system-wide
        e.g.: feature_enable link 1

    set_bpm <beats_per_minute>
        * set the global beats per minute transport value
        e.g.: set_bpm 120

    set_bpb <beats_per_bar>
        * set the global beats per bar transport value
        e.g.: set_bpb 4

    transport <rolling> <beats_per_bar> <beats_per_minute>
        * change the global transport state
        e.g.: transport 1 4 120

    transport_sync <mode>
        * change the transport sync mode
        * mode can be one of "none", "link" or "midi"
        e.g.: transport_sync "midi"

    output_data_ready
        * report feedback port ready for more messages

    track_info <instance_number> <name> <color> [bus|return|master]
        * pass the name and color of the mixer track the instance sits on, color as #RRGGBB or - for none
        * an LV2 plugin has no way to receive them, so mod-host answers -902
        e.g.: track_info 0 "Kick In" #FF8000

    remote_pages <instance_number>
        * get the number of remote-control pages of the plugin (8 parameters per page); 0 for an LV2 plugin
        e.g.: remote_pages 0

    remote_page_get <instance_number> <page_index>
        * get one remote-control page: resp 0 <page_id> <section_name> <page_name> <symbol> x8, - for an empty slot
        e.g.: remote_page_get 0 0

    param_info <instance_number> <param_symbol>
        * get what a control means: resp 0 <unit> <scale> <minimum> <maximum> <default> <step> <stable_symbol>
        * unit is an LV2 unit name (db, hz, ms, ...) or none, scale is linear, log or stepped, step 0 is continuous
        e.g.: param_info 0 "gain"

    help
        * show a help message

    quit
        bye!

For each effect added one client on JACK will be created. The names of clients
follow the standard: effect_\<instance_number\>

If a valid command is executed a response is given as following:

    resp <status> [value]

If status is a negative number an error has occurred. The table below shows the number of each error.

| status  | error                            |
| --------|----------------------------------|
| -1      | ERR\_INSTANCE\_INVALID           |
| -2      | ERR\_INSTANCE\_ALREADY\_EXISTS   |
| -3      | ERR\_INSTANCE\_NON\_EXISTS       |
| -4      | ERR\_INSTANCE\_UNLICENSED        |
| -101    | ERR\_LV2\_INVALID\_URI           |
| -102    | ERR\_LV2\_INSTANTIATION          |
| -103    | ERR\_LV2\_INVALID\_PARAM\_SYMBOL |
| -104    | ERR\_LV2\_INVALID\_PRESET\_URI   |
| -105    | ERR\_LV2\_CANT\_LOAD\_STATE      |
| -201    | ERR\_JACK\_CLIENT\_CREATION      |
| -202    | ERR\_JACK\_CLIENT\_ACTIVATION    |
| -203    | ERR\_JACK\_CLIENT\_DEACTIVATION  |
| -204    | ERR\_JACK\_PORT\_REGISTER        |
| -205    | ERR\_JACK\_PORT\_CONNECTION      |
| -206    | ERR\_JACK\_PORT\_DISCONNECTION   |
| -207    | ERR\_JACK\_VALUE\_OUT\_OF\_RANGE |
| -301    | ERR\_ASSIGNMENT\_ALREADY\_EXISTS |
| -302    | ERR\_ASSIGNMENT\_INVALID\_OP     |
| -303    | ERR\_ASSIGNMENT\_LIST\_FULL      |
| -304    | ERR\_ASSIGNMENT\_FAILED          |
| -304    | ERR\_ASSIGNMENT\_UNUSED          |
| -401    | ERR\_CONTROL\_CHAIN\_UNAVAILABLE |
| -402    | ERR\_LINK\_UNAVAILABLE           |
| -403    | ERR\_HMI\_UNAVAILABLE            |
| -404    | ERR\_EXTERNAL\_UI\_UNAVAILABLE   |
| -901    | ERR\_MEMORY\_ALLOCATION          |
| -902    | ERR\_INVALID\_OPERATION          |

A status zero or positive means that the command was executed successfully.
In case of the add command, the status returned is the instance number.
The value field exists for the param_get, remote_page_get and param_info commands.

When the plugin changes its remote-control pages, the feedback port gets:

    remote_pages_changed <instance_number>
