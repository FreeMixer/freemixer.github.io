// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 Pau Aliagas <linuxnow@gmail.com>

/* reac_hunt — WHICH END OF THE PAIRING WE TAKE ON A WIRE NOBODY CONFIGURED.
 *
 * THE RULE, and it is this daemon's own: no foreign master on the segment -> we drive
 * it, probe, grant, establish; ANY master on it -> we join as a slave and follow its
 * pace, a desk and a stagebox strapped to master alike, WHATEVER the segment is pinned to
 * (operator rulings 2026-09-09 and 2026-09-16; the width the box announces is what the
 * segment is then sized from, and it rides the verdict in `arb.rival_channels`); a rival
 * whose geometry nobody has ever captured -> we refuse, because there is nothing to size
 * a segment from. Nothing has to be written
 * down for any of it: a role a normal box needs hand-set is a defect in the defaults,
 * exactly as a hand-set rate would be.
 *
 * (A console describes the same three outcomes from its side, which is what an `auto`
 * role projects. DESIGN.md is this repo's law.)
 *
 * IT DECIDES NOTHING BY ITSELF THAT reac_arbitration HAS NOT ALREADY OBSERVED.
 * reac_arbitration stays passive — it publishes who drives the segment — and this
 * module is the thin ACT half over it: accumulate the sightings of one wire in the
 * discovery table the rest of the daemon already uses, ask reac_arbitrate what the
 * aggregate is, and turn that into the role this segment launches in. Everything about
 * classification (a rival is separated from a desk by its frame GEOMETRY, never by a
 * role byte — reac_arbitration.h) is reused, not restated.
 *
 * THE TWO AXES STAY TWO AXES. `enum reac_role` is the WIRE vocabulary
 * — which end of the desk<->stagebox pairing we present as — and has no `auto`. The
 * INTENT (`master` | `slave` | `auto`) lives in reac_role.h beside it, and `auto` is
 * what a segment with nothing configured means. This module resolves the second into
 * the first; the clock axis is untouched by any of it.
 *
 * WHY IT JOINS RATHER THAN FIGHTS, AND WHERE THE ONE REMAINING REFUSAL IS. REAC keeps ONE
 * master per segment, and we are never the second one. A clock is a clock whichever end of
 * the pairing sends it, so ANY wire with a box mastering it is JOINED — unpinned, pinned
 * `slave`, and since 2026-09-16 pinned `master` too (operator: "we set the daemons to
 * enroll any box, master or slave"). Both spellings before it were measured wrong on the
 * rig: an S-0808 on M refused on an unpinned wire vanished from the console (2026-09-09),
 * and an S-1608 on M refused on a PINNED one published a door with no audio while the
 * operator read "not detected" (2026-09-16). The switch position costs the head-amp, not
 * the audio, and saying so is the console's job. THE ONE REFUSAL LEFT is a rival whose
 * geometry has never been captured: there is nothing to size a segment from. A refused
 * segment is still PUBLISHED, as a door-only node carrying the refusal props (DESIGN.md,
 * 0.5.1), because a refusal nobody can see is indistinguishable from a daemon that is not
 * running.
 *
 * Main-thread only, like the discovery table it holds: one hunt per passive sniffer,
 * alive only until its segment is served (or refused). It transmits nothing; hearing is
 * the gate to serve on an UNPINNED wire, and this is what reads the hearing. On a PINNED
 * wire LINK is the gate — the pin is the operator's answer and a cold box has no frame
 * to offer — so the same object answers immediately and the sniffer is closed unused.
 */
#ifndef REAC_HUNT_H
#define REAC_HUNT_H

#include <reac/reac_arbitration.h>
#include <reac/reac_facts_timing.h>   /* REAC_ANNOUNCE_PERIOD_MS — a protocol fact */
#include <reac/reac_disco.h>
#include <reac/reac_role.h>

#include <stdint.h>
#include <stddef.h>

/* HOW LONG A VACANT WIRE IS WATCHED BEFORE WE TAKE IT — three master announce
 * cadences. The cadence is the protocol fact REAC_ANNOUNCE_PERIOD_MS (reac-protocol's
 * timing group, read through reac_facts_timing.h); it used to be a typed 3e9. This is
 * NOT the hold on a broadcast sender's verdict (reac_master_only_cadence_ns): that one is
 * a single master-only cadence, because a desk that IS sending proves itself within one;
 * this one is three, because it is waiting out a desk that may be sending nothing we
 * heard.
 *
 * The number is read off the protocol this daemon already emits, not picked: a master
 * announces itself with a cfea once per second and fills the gaps with FILLER
 * (`reac_master.c`, `announce_tick >= m->fps`, one frame per second at every rate; the
 * master heartbeat runs at the same ~1/s). One cadence would call a desk absent on a
 * single lost announce; two on two in a row; THREE is the first window that survives
 * two consecutive losses, and it still sits comfortably inside the 5 s
 * REAC_DISCO_STALE_NS bar this codebase already uses for "a device is really gone".
 *
 * The window bounds only the SILENT case. A desk that IS there is normally heard on its
 * first announce and joined then — the wait is what a wire with nothing on it costs,
 * once, and it is the difference between hunting for three seconds and hunting forever.
 */
#define REAC_HUNT_ANNOUNCES 3
#define REAC_HUNT_WINDOW_NS \
	((uint64_t)REAC_HUNT_ANNOUNCES * (uint64_t)REAC_ANNOUNCE_PERIOD_MS * 1000000ULL)

/* What the hunt has concluded about this segment. `HUNTING` is not a failure: it is the
 * honest state of a wire that has not answered yet, and it is REPORTED rather than spun
 * on: a state nobody can act on is still reported, never left as a silent spinner. */
enum reac_hunt_verdict {
	REAC_HUNT_HUNTING = 0,   /* nothing decides it yet; keep listening */
	REAC_HUNT_MASTER,        /* no master heard and a box is present: we drive and grant */
	REAC_HUNT_SLAVE,         /* somebody masters this wire: join it and follow its pace */
	REAC_HUNT_REFUSED,       /* a rival whose geometry has never been captured masters it:
	                          * say so, and publish a door about it */
};

const char *reac_hunt_verdict_name(enum reac_hunt_verdict v);

struct reac_hunt {
	/* The evidence, in the same table the established path publishes from — so the
	 * hunt's view of a wire and the segment's view of it are the same code. */
	struct reac_disco_table table;
	/* REAC is physically point-to-point, so a FILLER frame (checksum-exempt) is only
	 * trusted from the peer a real control frame already proved. Same defence the
	 * pacer's own classifier runs; the hunt is a segment too. */
	struct reac_disco_peer_lock lock;
	uint8_t our_mac[6];
	/* THE WIRE WAS PROVEN MASTERLESS (reac_knock.h) AND WE MAY TAKE IT. Not a pin and not
	 * a sighting: a licence, granted after REAC_KNOCK_LISTEN_NS in which a master — which
	 * fills every audio slot and cannot be present and silent — transmitted nothing. It
	 * replaces exactly one thing: the requirement to hear a BOX before driving a vacant
	 * wire. A cold box cannot produce that evidence (it spends a bounded flood on PHY-up
	 * and then never speaks again), so requiring it left two rig boxes mute on
	 * 2026-09-08. Everything else still rules over it: a desk heard is still joined, a
	 * stagebox on M is still refused, and the licence is cancelled the moment anything is
	 * heard inside the window. */
	int silence_proven;
	/* When the window started: the hunt's own opening, re-anchored to the FIRST sighting
	 * (reac_hunt_observe explains why). Never moved again — a second peer does not buy
	 * the wire another three seconds. */
	uint64_t opened_ns;
	/* A PER-SEGMENT ROLE THE OPERATOR SET (`REAC_ROLE_<segment>`). A pin is a SETTING
	 * — an intent, not an observation — so it does not wait on evidence of any kind,
	 * including a frame: the segment serves in the pinned role from the first step after
	 * link. It waited for a classifying frame until 2026-09-08, and a cold stagebox in
	 * slave mode emits nothing until a master announces to IT, so two pinned masters on
	 * the rig hunted forever for a frame only their own announce could have caused
	 * (DESIGN.md, "A cold stagebox is silent"). Whether the wire AGREES with
	 * the pin is then the listener's own arbitration to publish, and that disagreement
	 * only exists once an intent does. */
	int pinned;
	enum reac_role pin;
	enum reac_hunt_verdict verdict;
	/* The aggregate the current verdict was read from — the rival's MAC and kind for
	 * the refusal sentence, never re-derived by the caller. */
	struct reac_arbitration arb;
};

/* Start hunting on a segment. `our_mac` is this NIC's own address: our echo is not
 * evidence of anybody else. */
void reac_hunt_init(struct reac_hunt *h, const uint8_t our_mac[6], uint64_t now_ns);

/* Pin this segment's role, from `REAC_ROLE_<segment>`. Call once, before or after the
 * first frame; `master` and `slave` pin, and `auto` is expressed by not calling this at
 * all. A pinned hunt never elects and never waits: the next `reac_hunt_step` answers
 * with the pinned role on an empty table, so a pinned master drives a wire whose box has
 * not spoken and cannot speak until it does. A pinned MASTER yields to a BOX already
 * mastering the wire and joins it as a slave (2026-09-16) — that case reads only what the
 * table ALREADY holds, so it costs a cold wire nothing. */
void reac_hunt_pin(struct reac_hunt *h, enum reac_role role);

/* Grant the masterless licence (reac_knock.h): this wire carried nothing for the whole
 * observation window, so a vacant wire may be DRIVEN without first hearing a box on it.
 * Call once, when reac_knock says ACT_DRIVE. It does not outrank evidence — a desk or a
 * rival heard afterwards still decides — so it is safe to grant and then be overruled. */
void reac_hunt_silence_proven(struct reac_hunt *h);

/* Offer one raw frame. Returns 1 when it was a sighting that changed the table
 * OBSERVABLY (a new peer, a sharper role or model) — which is what deserves a log line;
 * 0 when it was a sighting that only refreshed liveness; -1 when the frame is not
 * evidence of REAC gear at all.
 *
 * `*out` is filled on any sighting (return >= 0) with THIS PEER'S SETTLED VERDICT —
 * the disco table's entry for that MAC, not the classification of the frame that
 * just arrived. One MAC is one box and deserves one answer: a box that has lost its
 * master floods broadcast filler, which is role-`unknown` by construction, so a
 * per-frame answer reports one box as `box` off its declaration and `unknown` off
 * its flood a millisecond later (live, VLAN 13, 2026-09-17). The MAC and the
 * sighting's own fields other than role/model/channels are the frame's. */
int reac_hunt_observe(struct reac_hunt *h, const uint8_t *frame, size_t len,
                      uint64_t now_ns, struct reac_disco_sighting *out);

/* Re-decide. Ages the table first, so an unplugged desk stops mastering the segment and
 * a box switched out of M stops mastering it, without anything latching. Returns 1 when
 * the verdict CHANGED (log it), 0 when it stands. */
int reac_hunt_step(struct reac_hunt *h, uint64_t now_ns);

/* The wire role the verdict resolves to. MASTER for a vacant wire, SLAVE for a wire
 * somebody else masters; meaningless (and never acted on) while HUNTING or REFUSED,
 * where it answers MASTER only because `enum reac_role` has no third value — the caller
 * gates on the verdict. */
enum reac_role reac_hunt_role(const struct reac_hunt *h);

/* Has any REAC gear been heard on this wire at all? Distinguishes "quiet" from
 * "undecided" for the report: could-not-decide must never render as found-nothing. */
int reac_hunt_heard_anything(const struct reac_hunt *h);

#endif /* REAC_HUNT_H */
