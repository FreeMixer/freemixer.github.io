/* SPDX-License-Identifier: GPL-3.0-or-later
 * Copyright (C) 2026 Pau Aliagas <linuxnow@gmail.com>
 *
 * omx_drive_instance.h — the DRIVE stage as a live insert for other
 * hosts: the shell's core, with no format in it.
 *
 * Under the HRP shells rule (one C core, several shells — what
 * differs is who calls it) and the drive stage's own law: drive is NATIVE
 * inside the console; this shell does not reopen that — it is the same kernel offered to a
 * host that is not openmixer.
 *
 * ## The face: init, resolve, run, latency
 *
 * Everything below is plain C over `omx_drive.h` and knows nothing about a plugin format. Its shape
 * is every instance face's: {@link omx_drive_instance_init} binds an instance to a declared rate,
 * {@link omx_drive_instance_resolve} takes the drive kernel's contract controls in their declared
 * order and user units (`amount` dB, `character`, `band_freq` Hz, `mix` %, `trim` dB, then the
 * `curve` and `band` choice indices, the `auto_gain` and `stereo_link` switches, the
 * `hf_rolloff` id and the `oversample` factor), {@link omx_drive_instance_run} runs the
 * kernel and
 * {@link omx_drive_instance_latency} publishes its latency. A plugin binding generated from the
 * contract calls them with no hand-written map.
 *
 * ## The oversampling factor
 *
 * `oversample` is a contract control (omx-contract 2.8.0): the shaper runs inside the shared
 * oversampler at 1x, 2x or 4x, the id being the factor, and comes up at 4X, the oversampler's
 * largest ({@link OMX_DRIVE_INSTANCE_FACTOR}). A factor change rebuilds the kernel's state for the
 * new factor inside resolve, at the block boundary, so no oversampler history designed for another
 * rate is ever run. The coefficient bank runs at the base rate, before the oversampler and after it,
 * so a factor change moves no coefficient and redesigns nothing.
 *
 * ## ZERO DUPLICATED DSP
 *
 * {@link omx_drive_instance_run} copies the host's input to its output and calls
 * `omx_drive_process` — the SAME inline the console's lane walk calls (mix_lane.h) — on it.
 * There is no second waveshaper, no second oversampler, no second auto-gain. What this file
 * owns is the RESOLVER: the console builds its `struct omx_drive` from word-atomic controls
 * plus TypeScript-designed coefficients (mixer_rt.c's resolve_fx_drive over console-rig.ts's
 * driveStateToNativeDrive); a foreign host hands us its controls and a rate, so
 * {@link omx_drive_instance_resolve} does the same job from those, with the coefficient design in C
 * (mix_drive_design.h — a pinned twin of the TypeScript, not a second opinion) and the time
 * constants from the kernel's own `omx_drive_time_constants`.
 *
 * ## NO WORKER, and why (the one place this shell is simpler than HRP's)
 *
 * HRP's live shell needs `lv2:worker` because its analysis is an FFT chain that must never run
 * in an audio callback. The drive has no analysis: its `run()` is a resolve (a dozen loads and
 * clamps, a coefficient redesign ONLY when a frequency port moved — a few trig calls, no
 * allocation) and the kernel, which is fixed work per sample with every buffer inline in
 * `struct omx_drive_state`. Nothing here needs a second thread, so none is asked for.
 *
 * ## LATENCY IS PUBLISHED, and it is the ELEMENT's number
 *
 * {@link omx_drive_instance_latency} is `omx_drive_latency`: the shared oversampler's round-trip
 * at the face's factor (72 base samples at 4x — "declared by the element,
 * derived by everyone else"; 48 at 2x, 0 at 1x), and 0 while bypassed, exactly as the console's `latencySamples`
 * row derives it. A plugin publishes it every cycle, so a host can compensate the dry paths
 * beside it.
 *
 * ## STEREO, 2 in / 2 out
 *
 * The kernel is a stereo pair with an optional right leg, and `stereoLink` (§4e: ONE auto-gain
 * path from both legs' summed energy) is a fact about a PAIR. A mono plugin instantiated twice
 * by a host cannot link, so the plugin is 2x2 and a host racking it on a mono strip feeds one
 * leg; the other runs on silence at no audible cost.
 */
#ifndef OMX_DRIVE_INSTANCE_H
#define OMX_DRIVE_INSTANCE_H

#include <stdint.h>
#include <string.h>

#include <omxdsp/fx/omx_drive.h>
#include <omxdsp/fx/omx_drive_design.h>
#include <omxdsp/omxdsp_definitions.h> /* the drive kernel's controls: every travel below */
#include <omxdsp/fx/omx_instance_io.h>
#include <omxdsp/omx_param.h>

#define OMX_DRIVE_INSTANCE_CHANNELS 2

/** The shared oversampler's largest factor, the `oversample` control's come-up. */
#define OMX_DRIVE_INSTANCE_FACTOR ((int)OMX_OVS_MAX_FACTOR)
OMXDSP_STATIC_ASSERT(OMX_DRIVE_OVERSAMPLES_DEFAULT == OMX_DRIVE_INSTANCE_FACTOR,
                     "the contract's oversample come-up is the oversampler's largest factor");
OMXDSP_STATIC_ASSERT(OMX_DRIVE_OVERSAMPLES_COUNT == 3u && OMX_DRIVE_OVERSAMPLES_1 == 1 && OMX_DRIVE_OVERSAMPLES_2 == 2 &&
                         OMX_DRIVE_OVERSAMPLES_4 == 4,
                     "the contract's oversample factors are the ones the drive's oversampler offers");
/** What the face designs the HF roll-off section at with the roll-off off (console-rig.ts:
 * `hfHz = ... ? 20000 : ...`). */
#define OMX_DRIVE_INSTANCE_HF_OFF_DESIGN_HZ 20000.0f

/** Control defaults: the contract's (DRIVE_*_RANGE.default); a choice comes up at its first id. */
#define OMX_DRIVE_INSTANCE_AMOUNT_DEFAULT ((float)OMX_DRIVE_AMOUNT_RANGE_DEFAULT)
#define OMX_DRIVE_INSTANCE_CHARACTER_DEFAULT ((float)OMX_DRIVE_CHARACTER_RANGE_DEFAULT)
#define OMX_DRIVE_INSTANCE_BAND_FREQ_DEFAULT ((float)OMX_DRIVE_BAND_FREQ_RANGE_DEFAULT)
#define OMX_DRIVE_INSTANCE_MIX_DEFAULT ((float)OMX_DRIVE_MIX_RANGE_DEFAULT)
#define OMX_DRIVE_INSTANCE_TRIM_DEFAULT ((float)OMX_DRIVE_TRIM_RANGE_DEFAULT)
#define OMX_DRIVE_INSTANCE_CURVE_DEFAULT OMX_DRIVE_SOFT
#define OMX_DRIVE_INSTANCE_BAND_DEFAULT OMX_DRIVE_BAND_FULL
#define OMX_DRIVE_INSTANCE_AUTO_GAIN_DEFAULT ((int)OMX_DRIVE_AUTO_GAINS_DEFAULT)
#define OMX_DRIVE_INSTANCE_STEREO_LINK_DEFAULT ((int)OMX_DRIVE_STEREO_LINKS_DEFAULT)
#define OMX_DRIVE_INSTANCE_HF_ROLLOFF_DEFAULT ((int)OMX_DRIVE_HF_ROLLOFFS_DEFAULT)
#define OMX_DRIVE_INSTANCE_OVERSAMPLE_DEFAULT ((int)OMX_DRIVE_OVERSAMPLES_DEFAULT)

/** One instance: the atom, the kernel's state (inline: the oversampler histories and the
 * compensation line), and what the coefficient bank was last designed for. Nothing is caller-owned. */
typedef struct {
  uint32_t rate;
  struct omx_drive atom;
  struct omx_drive_state state;
  /* What the coefficient bank was last designed for, so resolve() redesigns only on a change. */
  float designed_band_hz;
  float designed_hf_hz;
  int ready;
} OmxDriveInstance;

/**
 * Resolve the host's control values into the atom for this cycle. `bypass` non-zero disables the
 * atom. The arguments are the drive kernel's contract controls, in their declared order and user
 * units: `amount` (dB), `character` (-1..+1), `band_freq` (Hz), `mix` (percent) and `trim` (dB)
 * are clamped into their declared travels, a non-finite word reading as the declared default;
 * `curve` and `band` are the DRIVE_CURVES and DRIVE_BANDS indices (`enum omx_drive_curve`,
 * `enum omx_drive_band`), any other value reading as the first; `auto_gain` and `stereo_link` are
 * the DRIVE_AUTO_GAINS and DRIVE_STEREO_LINKS indices (0 off, 1 on), any other value reading as the
 * declared default; `hf_rolloff` is a DRIVE_HF_ROLLOFFS id (`enum omx_drive_hf_rolloffs`: 0 off, 1, 2), any
 * other value reading as the declared default; the corner in Hz comes from the contract's
 * `omx_drive_hf_rolloffs_value`, so a corner the low-pass design cannot take is never designed; `oversample` is a DRIVE_OVERSAMPLES id, the factor (1, 2 or 4), any other
 * value reading as the declared default (4). The clamps are the row's, applied
 * for the same reason the console's controller applies them: the kernel's contract requires mix in
 * [0,1], and a host is free to write anything to a port.
 *
 * Coefficients are redesigned only when `band_freq` or the roll-off corner moved; the state is
 * rebuilt for the new factor only when `oversample` moved, and the latency follows the factor.
 * Allocation-free.
 */
#define OMX_CONTRACT_STAGE "drive-instance/resolve"
static inline void omx_drive_instance_resolve(OmxDriveInstance *s, int bypass, float amount, float character,
                                              float band_freq, float mix, float trim, int curve, int band,
                                              int auto_gain, int stereo_link, int hf_rolloff, int oversample) {
  if (!s || !s->ready) return;
  /* CONTRACT (omx_contract.h). Whatever a host wrote to the ports, the atom leaves here inside
   * omx_drive_process's own PRE: mix in [0,1], the factor the state is built for, the bias weight
   * in [0,1], and the two gains finite and positive. */
  struct omx_drive *o = &s->atom;
  o->enabled = bypass ? 0 : 1;
  o->curve = curve >= OMX_DRIVE_SOFT && curve <= OMX_DRIVE_EXCITER ? curve : OMX_DRIVE_INSTANCE_CURVE_DEFAULT;
  o->band = band >= OMX_DRIVE_BAND_FULL && band <= OMX_DRIVE_BAND_TILT ? band : OMX_DRIVE_INSTANCE_BAND_DEFAULT;
  o->drive_lin = omx_db_to_lin(omx_clamp_or(amount, (float)OMX_DRIVE_AMOUNT_RANGE_MIN, (float)OMX_DRIVE_AMOUNT_RANGE_MAX,
                                            OMX_DRIVE_INSTANCE_AMOUNT_DEFAULT));
  /* even_w = (character + 1) / 2, the same fold resolve_fx_drive does. */
  o->even_w = 0.5f * (omx_clamp_or(character, (float)OMX_DRIVE_CHARACTER_RANGE_MIN, (float)OMX_DRIVE_CHARACTER_RANGE_MAX,
                                   OMX_DRIVE_INSTANCE_CHARACTER_DEFAULT) +
                      1.0f);
  o->mix = 0.01f * omx_clamp_or(mix, (float)OMX_DRIVE_MIX_RANGE_MIN, (float)OMX_DRIVE_MIX_RANGE_MAX,
                                OMX_DRIVE_INSTANCE_MIX_DEFAULT);
  o->trim_lin = omx_db_to_lin(omx_clamp_or(trim, (float)OMX_DRIVE_TRIM_RANGE_MIN, (float)OMX_DRIVE_TRIM_RANGE_MAX,
                                           OMX_DRIVE_INSTANCE_TRIM_DEFAULT));
  o->auto_gain = auto_gain == 0 || auto_gain == 1 ? auto_gain : OMX_DRIVE_INSTANCE_AUTO_GAIN_DEFAULT;
  o->stereo_link = stereo_link == 0 || stereo_link == 1 ? stereo_link : OMX_DRIVE_INSTANCE_STEREO_LINK_DEFAULT;
  const int hf = hf_rolloff == OMX_DRIVE_HF_ROLLOFFS_OFF || hf_rolloff == OMX_DRIVE_HF_ROLLOFFS_12000 ||
                         hf_rolloff == OMX_DRIVE_HF_ROLLOFFS_16000
                     ? hf_rolloff
                     : OMX_DRIVE_INSTANCE_HF_ROLLOFF_DEFAULT;
  float corner_hz = 0.0f;
  o->hf_on = omx_drive_hf_rolloffs_value(hf, &corner_hz) ? 1 : 0;
  const int factor = oversample == OMX_DRIVE_OVERSAMPLES_1 || oversample == OMX_DRIVE_OVERSAMPLES_2 ||
                             oversample == OMX_DRIVE_OVERSAMPLES_4
                         ? oversample
                         : OMX_DRIVE_INSTANCE_OVERSAMPLE_DEFAULT;
  if (factor != o->os_factor) {
    o->os_factor = factor;
    omx_drive_state_init(&s->state, factor);
  }
  const float hf_hz = o->hf_on ? corner_hz : OMX_DRIVE_INSTANCE_HF_OFF_DESIGN_HZ;
  const float band_hz = omx_clamp_or(band_freq, (float)OMX_DRIVE_BAND_FREQ_RANGE_MIN,
                                     (float)OMX_DRIVE_BAND_FREQ_RANGE_MAX, OMX_DRIVE_INSTANCE_BAND_FREQ_DEFAULT);
  if (band_hz != s->designed_band_hz || hf_hz != s->designed_hf_hz) {
    omx_drive_design_bank(o, band_hz, hf_hz, s->rate);
    s->designed_band_hz = band_hz;
    s->designed_hf_hz = hf_hz;
  }
  OMX_POST(o->mix >= 0.0f && o->mix <= 1.0f, "mix-in-unit-range");
  OMX_POST(o->even_w >= 0.0f && o->even_w <= 1.0f, "bias-weight-in-unit-range");
  OMX_POST(s->state.factor == o->os_factor, "state-built-for-the-factor");
  OMX_POST(o->drive_lin >= 1.0f && o->drive_lin - o->drive_lin == 0.0f, "drive-gain-finite-and-at-least-unity");
  OMX_POST(o->trim_lin > 0.0f && o->trim_lin - o->trim_lin == 0.0f, "trim-gain-finite-and-positive");
}
#undef OMX_CONTRACT_STAGE

/**
 * Bind an instance to its rate: the time constants, the state built for the default factor, the
 * contract's defaults resolved and the bank designed, engaged. Returns 1 when usable, 0 when not: a
 * rate the console does not declare is refused, leaving `ready` clear, and run() is then the
 * identity. Allocates nothing — the caller owns the struct.
 */
static inline int omx_drive_instance_init(OmxDriveInstance *s, float sr) {
  if (!omx_instance_bind(s, sizeof(*s), sr)) return 0;
  s->rate = (uint32_t)sr;
  omx_drive_time_constants(&s->atom, sr);
  s->atom.os_factor = OMX_DRIVE_INSTANCE_OVERSAMPLE_DEFAULT;
  omx_drive_state_init(&s->state, s->atom.os_factor);
  s->designed_band_hz = -1.0f; /* forces the first design */
  s->designed_hf_hz = -1.0f;
  s->ready = 1;
  omx_drive_instance_resolve(s, 0, OMX_DRIVE_INSTANCE_AMOUNT_DEFAULT, OMX_DRIVE_INSTANCE_CHARACTER_DEFAULT,
                             OMX_DRIVE_INSTANCE_BAND_FREQ_DEFAULT, OMX_DRIVE_INSTANCE_MIX_DEFAULT,
                             OMX_DRIVE_INSTANCE_TRIM_DEFAULT, OMX_DRIVE_INSTANCE_CURVE_DEFAULT,
                             OMX_DRIVE_INSTANCE_BAND_DEFAULT, OMX_DRIVE_INSTANCE_AUTO_GAIN_DEFAULT,
                             OMX_DRIVE_INSTANCE_STEREO_LINK_DEFAULT, OMX_DRIVE_INSTANCE_HF_ROLLOFF_DEFAULT,
                             OMX_DRIVE_INSTANCE_OVERSAMPLE_DEFAULT);
  return 1;
}

/**
 * One cycle: `out = drive(in)` for both legs, `n` frames. `in_*` and `out_*` may alias. Not ready,
 * or bypassed, is a copy and nothing else — the kernel's own "zero cost when disengaged" (§4g),
 * reached through the same `enabled` word.
 */
#define OMX_CONTRACT_STAGE "drive-instance/run"
static inline void omx_drive_instance_run(OmxDriveInstance *s, const float *in_l, const float *in_r, float *out_l,
                                          float *out_r, uint32_t n) {
  /* CONTRACT (omx_contract.h). Finite in, finite out, on both legs — the kernel's own law,
   * restated at the host boundary because the copy is this function's. */
  if (!omx_instance_block_ok(in_l, in_r, out_l, out_r, n)) return;
  OMX_PRE(omx_block_pair_finite(in_l, in_r, n), "finite-in");
  omx_instance_copy(in_l, in_r, out_l, out_r, n);
  if (!s || !s->ready) return;
  omx_drive_process(out_l, out_r, n, &s->atom, &s->state);
  OMX_POST(omx_block_pair_finite(out_l, out_r, n), "finite-out");
}
#undef OMX_CONTRACT_STAGE

/** The stage's declared latency in frames at the instance rate — the element's at the resolved
 * factor (0, 48 or 72 at 1x, 2x, 4x), 0 while bypassed or not ready. */
static inline uint32_t omx_drive_instance_latency(const OmxDriveInstance *s) {
  return s && s->ready ? (uint32_t)omx_drive_latency(&s->atom) : 0u;
}

#endif /* OMX_DRIVE_INSTANCE_H */
